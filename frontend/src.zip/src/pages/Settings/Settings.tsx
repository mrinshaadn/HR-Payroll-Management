import React, { useState } from 'react';
import { useHR } from '../../context/HRContext';
import { 
  Building, 
  User, 
  Bell, 
  CreditCard, 
  Grid, 
  Upload, 
  Check, 
  HelpCircle,
  Save,
  Clock,
  Shield,
  HelpCircle as QuestionIcon
} from 'lucide-react';

export default function Settings() {
  const { config, updateSettings, addNotification } = useHR();

  const [activeTab, setActiveTab] = useState<'Org' | 'Account' | 'Notif' | 'Security'>('Org');

  // Working inputs state
  const [companyName, setCompanyName] = useState(config.companyName);
  const [adminEmail, setAdminEmail] = useState(config.adminEmail);
  const [payCycle, setPayCycle] = useState(config.payCycle);
  const [timezone, setTimezone] = useState(config.timezone);
  const [twoFactor, setTwoFactor] = useState(config.requireTwoFactor);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      companyName,
      adminEmail,
      payCycle,
      timezone,
      requireTwoFactor: twoFactor
    });
    addNotification('System configurations updated successfully.', 'success');
  };

  return (
    <div className="space-y-6">
      
      {/* HEADER BAR */}
      <div>
        <h1 className="text-xl font-extrabold tracking-tight text-slate-900 dark:text-white md:text-2xl">Configurations</h1>
        <p className="text-xs font-semibold text-slate-400 dark:text-slate-500">Fine tune system presets, notification thresholds, and security parameters</p>
      </div>

      {/* CORE 2-COLUMN SETTINGS SCREEN */}
      <div className="grid gap-6 lg:grid-cols-4">
        
        {/* Left Column Category list */}
        <div className="space-y-1.5">
          {[
            { id: 'Org', label: 'Organization Setup', icon: Building },
            { id: 'Account', label: 'Admin Account', icon: User },
            { id: 'Notif', label: 'System alerts & Logs', icon: Bell },
            { id: 'Security', label: 'Security & Access', icon: Shield }
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={`flex w-full items-center space-x-2.5 rounded-lg px-4 py-2.5 text-xs font-bold tracking-wide transition ${
                activeTab === item.id
                  ? 'bg-blue-600 text-white font-extrabold shadow-sm'
                  : 'bg-white hover:bg-slate-100 text-slate-600 dark:bg-slate-850 dark:text-slate-300 dark:hover:bg-slate-800'
              }`}
            >
              <item.icon className="h-4 w-4" />
              <span>{item.label}</span>
            </button>
          ))}
        </div>

        {/* Right Settings panel (3 Columns) */}
        <div className="lg:col-span-3">
          <form onSubmit={handleSaveSettings} className="rounded-xl border border-slate-100 bg-white p-6 shadow-sm dark:border-slate-805 dark:bg-slate-850 space-y-6">
            
            {/* TAB 1: ORGANIZATIONAL DETAILS */}
            {activeTab === 'Org' && (
              <div className="space-y-6">
                <div className="border-b border-slate-50 pb-3 dark:border-slate-805">
                  <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-450">Horizon Corporate Identity</h3>
                  <p className="text-[10px] text-slate-400">Manage corporate legal identities and geographic assets</p>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <img
                      src="https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?w=150"
                      alt="Corporate Logo"
                      className="h-14 w-14 rounded-lg object-cover border border-slate-200 dark:border-slate-700"
                    />
                    <button
                      type="button"
                      onClick={() => addNotification('Logo editor triggered.', 'info')}
                      className="absolute -bottom-1 -right-1 rounded bg-blue-600 p-1 text-white hover:bg-blue-700"
                    >
                      <Upload className="h-3 w-3" />
                    </button>
                  </div>
                  <div>
                    <h4 className="text-xs font-extrabold text-slate-800 dark:text-slate-200">Corporate Identity Brand Logo</h4>
                    <p className="text-[10px] text-slate-400 mt-0.5 font-semibold">Recommended: 256x256 WebP or SVG format</p>
                  </div>
                </div>

                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-450">Company Legal Name</label>
                    <input
                      required
                      type="text"
                      value={companyName}
                      onChange={(e) => setCompanyName(e.target.value)}
                      className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-100"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-450">General Admin Contact Email</label>
                    <input
                      required
                      type="email"
                      value={adminEmail}
                      onChange={(e) => setAdminEmail(e.target.value)}
                      className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-100"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-450">Active Payroll Disbursals Cycle</label>
                    <select
                      value={payCycle}
                      onChange={(e) => setPayCycle(e.target.value as any)}
                      className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-2 text-xs text-slate-850 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-300"
                    >
                      <option value="Bi-weekly">Bi-weekly Period (Every 14 Days)</option>
                      <option value="Semi-monthly">Semi-monthly Period (15th and 30th)</option>
                      <option value="Monthly">Monthly Period (Last slot monthly)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-450">Operating Timezone Selector</label>
                    <select
                      value={timezone}
                      onChange={(e) => setTimezone(e.target.value)}
                      className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-2 text-xs text-slate-850 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-300"
                    >
                      <option value="EST - Eastern Standard Time">EST - Eastern Standard Time (NYC)</option>
                      <option value="PST - Pacific Standard Time">PST - Pacific Standard Time (SF)</option>
                      <option value="BST - British Summer Time">BST - British Summer Time (London)</option>
                      <option value="IST - Indian Standard Time">IST - Indian Standard Time (Delhi)</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: ADMIN CONFIG ACCOUNT */}
            {activeTab === 'Account' && (
              <div className="space-y-4">
                <div className="border-b border-slate-50 pb-3 dark:border-slate-805">
                  <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-450">Administrator Profile</h3>
                </div>
                <div className="grid gap-4 sm:grid-cols-2 text-xs">
                  <div>
                    <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">Assigned Corporate Level</span>
                    <p className="text-slate-800 dark:text-white mt-1 font-bold">System Super-User Admin</p>
                  </div>
                  <div>
                    <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">Active SSO Link</span>
                    <p className="text-slate-800 dark:text-white mt-1 font-bold">Google Workspace Active directory</p>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 3: ALERTS LOG LEVEL */}
            {activeTab === 'Notif' && (
              <div className="space-y-4">
                <div className="border-b border-slate-50 pb-3 dark:border-slate-805">
                  <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-450">Operational Webhook logs</h3>
                </div>
                <div className="space-y-2 text-xs font-semibold">
                  {['Notify supervisor on leave request creation', 'Notify employee on paycheck disburse', 'Record daily late clock exceptions'].map((label, idx) => (
                    <label key={idx} className="flex items-center space-x-3 cursor-pointer">
                      <input type="checkbox" defaultChecked className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 h-4 w-4" />
                      <span className="text-slate-700 dark:text-slate-300">{label}</span>
                    </label>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 4: TWO FACTOR SECURITY ACTIONS */}
            {activeTab === 'Security' && (
              <div className="space-y-4">
                <div className="border-b border-slate-50 pb-3 dark:border-slate-805">
                  <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-450">Corporate Security protocols</h3>
                </div>
                
                <label className="flex items-center space-x-3 cursor-pointer p-3 rounded-lg bg-rose-500/5 border border-rose-500/10 dark:bg-rose-950/10 dark:border-rose-950/30">
                  <input
                    type="checkbox"
                    checked={twoFactor}
                    onChange={(e) => setTwoFactor(e.target.checked)}
                    className="rounded border-slate-300 text-blue-600 h-4 w-4 focus:ring-rose-500"
                  />
                  <div>
                    <p className="text-xs font-extrabold text-slate-800 dark:text-slate-200">Enforce Multi-Factor Two-Factor Authentication</p>
                    <p className="text-[10px] text-slate-400 mt-0.5 leading-snug font-medium">Require all corporate managers to verify actions via 2FA mobile passkeys</p>
                  </div>
                </label>
              </div>
            )}

            {/* Footer Form Submission control panel */}
            <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-50 dark:border-slate-800">
              <button
                type="button"
                onClick={() => addNotification('Pending configurations discarded.', 'info')}
                className="rounded-lg border border-slate-200 px-4 py-2 text-xs font-bold text-slate-705 hover:bg-slate-50 dark:border-slate-800 dark:text-slate-200 dark:hover:bg-slate-750 transition"
              >
                Discard Configurations
              </button>
              <button
                type="submit"
                className="inline-flex items-center space-x-1.5 rounded-lg bg-blue-600 px-5 py-2 text-xs font-black text-white hover:bg-blue-700 shadow-sm"
              >
                <Save className="h-4 w-4" />
                <span>Save Configurations</span>
              </button>
            </div>

          </form>
        </div>

      </div>

    </div>
  );
}
