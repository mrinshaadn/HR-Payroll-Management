import React, { useState } from 'react';
import { useHR } from '../../context/HRContext';
import { 
  Users, 
  Clock, 
  MapPin, 
  AlertTriangle, 
  UserX, 
  CalendarCheck,
  TrendingUp,
  Filter,
  ArrowRight,
  Download,
  ChevronRight
} from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, Tooltip, PieChart, Pie, Cell } from 'recharts';

const trendData = [
  { day: '1', count: 420 },
  { day: '3', count: 430 },
  { day: '6', count: 425 },
  { day: '9', count: 450 },
  { day: '12', count: 442 },
  { day: '15', count: 448 },
  { day: '18', count: 460 },
  { day: '21', count: 452 },
  { day: '24', count: 458 },
  { day: '27', count: 452 },
  { day: '30', count: 462 }
];

const pieData = [
  { name: 'Morning', value: 55, color: '#004ac6' },
  { name: 'Evening', value: 25, color: '#2563eb' },
  { name: 'Night', value: 12, color: '#4338ca' },
  { name: 'Remote', value: 8, color: '#38bdf8' }
];

const exceptions = [
  { title: '3 Missing Check-outs', text: 'Above 3 missing check-outs', type: 'error' },
  { title: '8 Late Arrivals', text: 'Arrived to have 8 late arrivals', type: 'warning' },
  { title: '2 Shift Conflicts', text: 'Over emsle 2 shift conflicts', type: 'info' }
];

export default function Attendance() {
  const { attendanceRecords, clockInActive, addNotification } = useHR();
  const [filterClass, setFilterClass] = useState('All');

  const [chartWidth, setChartWidth] = React.useState(0);
  const containerRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    if (!containerRef.current) return;
    const observer = new ResizeObserver((entries) => {
      if (entries[0]) {
        setChartWidth(entries[0].contentRect.width);
      }
    });
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  const filteredRecords = attendanceRecords.filter(r => {
    if (filterClass === 'All') return true;
    return r.status.toLowerCase() === filterClass.toLowerCase();
  });

  const handleExportCSV = () => {
    addNotification('Attendance ledger exported as CSV.', 'success');
  };

  return (
    <div className="space-y-6">
      
      {/* HEADER SECTION */}
      <div className="flex flex-col justify-between space-y-3 sm:flex-row sm:items-center sm:space-y-0">
        <div>
          <h1 className="text-xl font-extrabold tracking-tight text-slate-900 dark:text-white md:text-2xl">Attendance Tracker</h1>
          <p className="text-xs font-semibold text-slate-400 dark:text-slate-500">Live operational clocking ledger and exception manager</p>
        </div>
        <button
          onClick={handleExportCSV}
          className="inline-flex h-9 items-center space-x-1.5 rounded-lg border border-slate-200 bg-white px-3.5 text-xs font-bold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-750 transition shadow-sm"
        >
          <Download className="h-3.5 w-3.5" />
          <span>Export Excel CSV</span>
        </button>
      </div>

      {/* METRIC SUMMARIES */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        
        {/* Metric 1 */}
        <div className="flex items-center justify-between rounded-xl border border-slate-100 bg-white p-4 shadow-sm dark:border-slate-805 dark:bg-slate-850">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Present Today</span>
            <div className="flex items-baseline space-x-2 mt-1">
              <span className="text-2xl font-black text-slate-950 dark:text-white">452</span>
              <span className="text-[10px] font-bold text-emerald-500 flex items-center">&uarr; +2.4%</span>
            </div>
          </div>
          <div className="rounded-lg bg-emerald-50 p-2 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400">
            <CalendarCheck className="h-4 w-4" />
          </div>
        </div>

        {/* Metric 2 */}
        <div className="flex items-center justify-between rounded-xl border border-slate-100 bg-white p-4 shadow-sm dark:border-slate-805 dark:bg-slate-850">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Absent Today</span>
            <div className="flex items-baseline space-x-2 mt-1">
              <span className="text-2xl font-black text-slate-950 dark:text-white">12</span>
              <span className="text-[10px] font-semibold text-rose-500 flex items-center">&darr; -0.8%</span>
            </div>
          </div>
          <div className="rounded-lg bg-rose-50 p-2 text-rose-600 dark:bg-rose-950/40" style={{ color: '#ef4444' }}>
            <UserX className="h-4 w-4" />
          </div>
        </div>

        {/* Metric 3 */}
        <div className="flex items-center justify-between rounded-xl border border-slate-100 bg-white p-4 shadow-sm dark:border-slate-805 dark:bg-slate-850">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Late Arrivals</span>
            <div className="flex items-baseline space-x-2 mt-1">
              <span className="text-2xl font-black text-slate-950 dark:text-white">8</span>
              <span className="text-[10px] font-bold text-amber-500 flex items-center">&uarr; +1.5%</span>
            </div>
          </div>
          <div className="rounded-lg bg-amber-50 p-2 text-amber-600 dark:bg-amber-950/40 dark:text-amber-400">
            <Clock className="h-4 w-4" />
          </div>
        </div>

        {/* Metric 4 */}
        <div className="flex items-center justify-between rounded-xl border border-slate-100 bg-white p-4 shadow-sm dark:border-slate-805 dark:bg-slate-850">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Overtime Link</span>
            <div className="flex items-baseline space-x-2 mt-1">
              <span className="text-2xl font-black text-slate-950 dark:text-white">24.5 hrs</span>
              <span className="text-[10px] font-bold text-emerald-500 flex items-center">&uarr; +3%</span>
            </div>
          </div>
          <div className="rounded-lg bg-purple-50 p-2 text-purple-600 dark:bg-purple-950/40 dark:text-purple-400">
            <TrendingUp className="h-4 w-4" />
          </div>
        </div>

      </div>

      {/* TREND CHART */}
      <div className="rounded-xl border border-slate-100 bg-white p-5 shadow-sm dark:border-slate-805 dark:bg-slate-850">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
          <div>
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-400">Attendance Trends (Last 30 days)</h3>
            <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500 mt-0.5">Physical headcount presence graph</p>
          </div>
          <span className="rounded bg-slate-150 px-2.5 py-1 text-[10px] font-bold text-slate-600 dark:bg-slate-800 dark:text-slate-400">Last 30 Days</span>
        </div>
        <div className="h-44 w-full mt-4" ref={containerRef}>
          {chartWidth > 0 && (
            <AreaChart width={chartWidth} height={176} data={trendData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
              <defs>
                <linearGradient id="attendanceColor" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.25}/>
                  <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <XAxis dataKey="day" tick={{ fontSize: 9 }} stroke="#94a3b8" />
              <Tooltip contentStyle={{ fontSize: '10px' }} />
              <Area type="monotone" dataKey="count" stroke="#4f46e5" strokeWidth={2.5} fillOpacity={1} fill="url(#attendanceColor)" />
            </AreaChart>
          )}
        </div>
      </div>

      {/* DETAILED LEDGER GRID */}
      <div className="grid gap-6 lg:grid-cols-3">
        
        {/* Core Daily table */}
        <div className="space-y-4 lg:col-span-2">
          
          {/* Header layout filter */}
          <div className="rounded-xl border border-slate-100 bg-white p-4 shadow-sm dark:border-slate-805 dark:bg-slate-850 flex items-center justify-between">
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-400">Daily Attendance Log</h3>
            
            <div className="flex items-center space-x-2">
              <Filter className="h-4 w-4 text-slate-400" />
              <div className="flex space-x-1">
                {['All', 'Present', 'Late', 'WFH', 'Absent'].map((filter) => (
                  <button
                    key={filter}
                    onClick={() => setFilterClass(filter)}
                    className={`rounded-md px-2.5 py-1 text-[10px] font-bold transition ${
                      filterClass === filter
                        ? 'bg-blue-600 text-white font-extrabold shadow-sm'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:hover:bg-slate-750'
                    }`}
                  >
                    {filter}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="overflow-hidden rounded-xl border border-slate-100 bg-white shadow-sm dark:border-slate-805 dark:bg-slate-850">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-left">
                <thead>
                  <tr className="border-b border-slate-100 bg-slate-50/70 text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:border-slate-800 dark:bg-slate-800/40">
                    <th className="px-6 py-3">Employee Name</th>
                    <th className="px-6 py-3">Shift</th>
                    <th className="px-6 py-3">Clock In</th>
                    <th className="px-6 py-3">Clock Out</th>
                    <th className="px-6 py-3">Hours</th>
                    <th className="px-6 py-3">Overtime</th>
                    <th className="px-6 py-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs font-medium dark:divide-slate-800/40">
                  {filteredRecords.map((rec) => (
                    <tr key={rec.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/10">
                      
                      <td className="px-6 py-3.5">
                        <div className="flex items-center space-x-2.5">
                          <img src={rec.avatar} alt="User" className="h-7.5 w-7.5 rounded-full object-cover" />
                          <div>
                            <p className="font-extrabold text-slate-800 dark:text-slate-200">{rec.name}</p>
                            <p className="text-[9px] text-slate-400 dark:text-slate-500 font-mono">{rec.employeeId}</p>
                          </div>
                        </div>
                      </td>

                      <td className="px-6 py-3.5 text-slate-600 dark:text-slate-400">{rec.shiftType}</td>
                      <td className="px-6 py-3.5 font-mono text-slate-650 dark:text-slate-350">{rec.clockIn}</td>
                      <td className="px-6 py-3.5 font-mono text-slate-650 dark:text-slate-350">{rec.clockOut}</td>
                      <td className="px-6 py-3.5 text-slate-600 dark:text-slate-400">{rec.workHours}</td>
                      <td className="px-6 py-3.5 font-mono text-slate-600 dark:text-slate-400">{rec.overtime}</td>
                      
                      <td className="px-6 py-3.5">
                        <span className={`inline-flex rounded-full px-2 py-0.5 text-[9px] font-black uppercase ${
                          rec.status === 'Present'
                            ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30'
                            : rec.status === 'Late'
                            ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/30'
                            : rec.status === 'WFH'
                            ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/30'
                            : 'bg-rose-50 text-rose-700 dark:bg-rose-950/30'
                        }`}>
                          {rec.status}
                        </span>
                      </td>

                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>

        {/* RIGHT AREA COLUMNS Panels */}
        <div className="space-y-6">
          
          {/* Exceptions alert panel */}
          <div className="rounded-xl border border-slate-100 bg-white p-5 shadow-sm dark:border-slate-805 dark:bg-slate-850">
            <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-400 mb-4 pb-2 border-b border-slate-50 dark:border-slate-800">
              Exceptions &amp; Alerts
            </h4>
            <div className="space-y-3">
              {exceptions.map((ex, idx) => (
                <div key={idx} className="flex items-start justify-between rounded-lg bg-rose-50/35 border border-rose-100/30 p-3 dark:bg-slate-800/40 dark:border-slate-800">
                  <div className="flex items-start space-x-2.5">
                    <AlertTriangle className={`h-4 w-4 mt-0.5 ${ex.type === 'error' ? 'text-rose-500' : 'text-amber-500'}`} />
                    <div>
                      <h5 className="text-xs font-extrabold text-slate-800 dark:text-slate-200">{ex.title}</h5>
                      <span className="text-[10px] text-slate-400 dark:text-slate-500">{ex.text}</span>
                    </div>
                  </div>
                  <ChevronRight className="h-4 w-4 text-slate-300" />
                </div>
              ))}
            </div>
          </div>

          {/* Shift Distribution Wheel */}
          <div className="rounded-xl border border-slate-100 bg-white p-5 shadow-sm dark:border-slate-805 dark:bg-slate-850">
            <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-400 mb-4 pb-2 border-b border-slate-50 dark:border-slate-800">
              Daily Shift Allocation
            </h4>
            
            <div className="flex items-center justify-between">
              <div className="h-28 w-28">
                <PieChart width={112} height={112}>
                  <Pie data={pieData} innerRadius={20} outerRadius={32} dataKey="value">
                    {pieData.map((e, index) => (
                      <Cell key={`cell-${index}`} fill={e.color} />
                    ))}
                  </Pie>
                </PieChart>
              </div>
              <div className="flex-1 pl-4 space-y-1.5 text-[10px] font-bold text-slate-500">
                {pieData.map((entry, idx) => (
                  <div key={idx} className="flex items-center justify-between">
                    <div className="flex items-center space-x-1.5">
                      <span className="h-2 w-2 rounded-full" style={{ backgroundColor: entry.color }} />
                      <span>{entry.name}</span>
                    </div>
                    <span className="text-slate-850 dark:text-white">{entry.value}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Live Action clocking terminal */}
          <div className="rounded-xl border border-slate-100 bg-white p-5 shadow-sm dark:border-slate-805 dark:bg-slate-850">
            <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-400 mb-3 pb-2 border-b border-slate-50 dark:border-slate-800">
              Live Terminal Log
            </h4>
            
            <div className="space-y-4 max-h-48 overflow-y-auto pr-1">
              {clockInActive ? (
                <div className="flex items-start space-x-3 text-xs leading-tight">
                  <div className="h-2 w-2 mt-1.5 rounded-full bg-emerald-500 pulse-glow" />
                  <div>
                    <p className="font-bold text-slate-700 dark:text-slate-350">Eleanor Vance clocked in</p>
                    <span className="text-[9px] text-slate-400">{new Date().toLocaleTimeString()} &bull; NYC Primary Office Hub</span>
                  </div>
                </div>
              ) : null}

              <div className="flex items-start space-x-3 text-xs leading-tight">
                <div className="h-2 w-2 mt-1.5 rounded-full bg-slate-350 dark:bg-slate-600" />
                <div>
                  <p className="font-bold text-slate-700 dark:text-slate-350">Michael Chen logged Out</p>
                  <span className="text-[9px] text-slate-400">05:45 PM &bull; SF Office Site</span>
                </div>
              </div>

              <div className="flex items-start space-x-3 text-xs leading-tight">
                <div className="h-2 w-2 mt-1.5 rounded-full bg-emerald-500" />
                <div>
                  <p className="font-bold text-slate-700 dark:text-slate-350">David Miller registered clocking In</p>
                  <span className="text-[9px] text-slate-400">08:52 AM &bull; Toronto Core Site</span>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>

    </div>
  );
}
