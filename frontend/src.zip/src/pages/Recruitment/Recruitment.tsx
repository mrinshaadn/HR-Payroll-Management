import React, { useState } from 'react';
import { useHR } from '../../context/HRContext';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip 
} from 'recharts';
import { 
  Plus, 
  Users, 
  Briefcase, 
  Trash2,
  X,
  ArrowRight
} from 'lucide-react';

const recruitFunnelMap = [
  { stage: 'Applied', count: 180 },
  { stage: 'Screening', count: 120 },
  { stage: 'Interview', count: 75 },
  { stage: 'Offer Stage', count: 32 },
  { stage: 'Hired', count: 18 }
];

export default function Recruitment() {
  const { 
    candidates, 
    addCandidate, 
    deleteCandidate, 
    addNotification 
  } = useHR();

  const [showCandModal, setShowCandModal] = useState(false);
  const [candName, setCandName] = useState('');
  const [candRole, setCandRole] = useState('');
  const [candStatus, setCandStatus] = useState<'APPLIED' | 'SCREENING' | 'INTERVIEWING' | 'OFFER_MADE' | 'HIRED'>('APPLIED');

  const [funnelWidth, setFunnelWidth] = React.useState(0);
  const funnelRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    if (!funnelRef.current) return;
    const observer = new ResizeObserver((entries) => {
      if (entries[0]) {
        setFunnelWidth(entries[0].contentRect.width);
      }
    });
    observer.observe(funnelRef.current);
    return () => observer.disconnect();
  }, []);

  const handleAddCandidate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!candName || !candRole) {
      addNotification('Please enter candidate Name and applied Role.', 'warning');
      return;
    }
    addCandidate({
      name: candName,
      role: candRole,
      status: candStatus,
      appliedDate: 'Just Now'
    });
    setCandName('');
    setCandRole('');
    setShowCandModal(false);
  };

  return (
    <div className="space-y-6">
      
      {/* HEADER ROW */}
      <div className="flex flex-col justify-between space-y-3 sm:flex-row sm:items-center sm:space-y-0">
        <div>
          <h1 className="text-xl font-extrabold tracking-tight text-slate-900 dark:text-white md:text-2xl">Recruitment Board</h1>
          <p className="text-xs font-semibold text-slate-400 dark:text-slate-500">Corporate intelligence grids, vacancy funnels, and candidate ledger</p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        
        {/* Chart: Funnel drops bar chart */}
        <div className="rounded-xl border border-slate-100 bg-white p-5 shadow-sm dark:border-slate-805 dark:bg-slate-850 md:col-span-2 space-y-4">
          <div>
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-400">Recruitment Conversion Funnel</h3>
            <p className="text-[10px] text-slate-400">Funnel metrics showing conversions from Apply to Hire</p>
          </div>
          <div className="h-44 w-full" ref={funnelRef}>
            {funnelWidth > 0 && (
              <BarChart width={funnelWidth} height={176} data={recruitFunnelMap} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="stage" tick={{ fontSize: 9 }} stroke="#94a3b8" />
                <YAxis tick={{ fontSize: 9 }} stroke="#94a3b8" />
                <Tooltip contentStyle={{ fontSize: '10px' }} />
                <Bar dataKey="count" fill="#4f46e5" radius={[4, 4, 0, 0]} barSize={34} />
              </BarChart>
            )}
          </div>
        </div>

        {/* Quick KPIs */}
        <div className="rounded-xl border border-slate-100 bg-white p-5 shadow-sm dark:border-slate-805 dark:bg-slate-850 flex flex-col justify-between">
          <div className="space-y-4">
            <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-400">Recruitment Summary</h4>
            <div className="space-y-2 text-xs font-semibold">
              <div className="flex justify-between border-b border-slate-50 pb-2 dark:border-slate-800">
                <span className="text-slate-400">Open Vacancies</span>
                <span className="text-slate-850 dark:text-white">14 roles</span>
              </div>
              <div className="flex justify-between border-b border-slate-50 pb-2 dark:border-slate-800">
                <span className="text-slate-400">Yield conversion</span>
                <span className="text-emerald-500">10% standard</span>
              </div>
              <div className="flex justify-between border-b border-slate-50 pb-2 dark:border-slate-800">
                <span className="text-slate-400">Avg Time-to-Hire</span>
                <span className="text-slate-850 dark:text-white">24 Days</span>
              </div>
            </div>
          </div>
          <button
            onClick={() => setShowCandModal(true)}
            className="mt-6 w-full rounded-lg bg-slate-950 py-2.5 text-xs font-extrabold text-white flex items-center justify-center space-x-1.5 hover:bg-slate-850 dark:bg-blue-600 dark:hover:bg-blue-700 transition"
          >
            <Plus className="h-4 w-4" />
            <span>Register Candidate</span>
          </button>
        </div>

      </div>

      {/* Candidates Ledger Table */}
      <div className="overflow-hidden rounded-xl border border-slate-100 bg-white shadow-sm dark:border-slate-805 dark:bg-slate-850">
        <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800">
          <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-400">Active Candidates Repository</h3>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50/70 text-[10px] font-extrabold uppercase tracking-widest text-slate-400 dark:border-slate-800 dark:bg-slate-800/40">
                <th className="px-6 py-3.5">Candidate Name</th>
                <th className="px-6 py-3.5">Intended Role</th>
                <th className="px-6 py-3.5">Date Registered</th>
                <th className="px-6 py-3.5">Funnel Pipeline Status</th>
                <th className="px-6 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs font-bold text-slate-700 dark:divide-slate-800/40 dark:text-slate-300">
              {candidates.map((cand) => (
                <tr key={cand.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/10 transition">
                  
                  <td className="px-6 py-3.5">
                    <span className="text-slate-950 dark:text-white tracking-tight">{cand.name}</span>
                  </td>
                  
                  <td className="px-6 py-3.5 text-slate-500 font-semibold">{cand.role}</td>
                  <td className="px-6 py-3.5 text-slate-400 font-semibold">{cand.appliedDate ?? 'Just Now'}</td>
                  
                  <td className="px-6 py-3.5">
                    <span className={`inline-flex rounded-full px-2 py-0.5 text-[9px] font-black uppercase tracking-wide ${
                      (cand.status ?? cand.stage ?? '').toUpperCase() === 'HIRED'
                        ? 'bg-emerald-50 text-emerald-700'
                        : (cand.status ?? cand.stage ?? '').toUpperCase() === 'APPLIED'
                        ? 'bg-blue-50 text-blue-700'
                        : (cand.status ?? cand.stage ?? '').toUpperCase() === 'INTERVIEWING' || (cand.status ?? cand.stage ?? '').toUpperCase() === 'INTERVIEWS'
                        ? 'bg-amber-50 text-amber-700'
                        : 'bg-indigo-50 text-indigo-700'
                    }`}>
                      {(cand.status ?? cand.stage ?? '').replace('_', ' ')}
                    </span>
                  </td>

                  <td className="px-6 py-3.5 text-right">
                    <button
                      onClick={() => deleteCandidate(cand.id)}
                      className="p-1.5 rounded hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition"
                      title="Reject profile"
                    >
                      <Trash2 className="h-4.5 w-4.5" />
                    </button>
                  </td>

                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* REGISTER CANDIDATE MODAL */}
      {showCandModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-[2px] p-4">
          <div className="w-full max-w-sm rounded-xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-slate-100 uppercase tracking-widest">Register Vacancy Profile</h3>
              <button onClick={() => setShowCandModal(false)} className="rounded p-1 hover:bg-slate-100 dark:hover:bg-slate-800">
                <X className="h-4 w-4 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleAddCandidate} className="mt-4 space-y-4">
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Candidate Full Name *</label>
                <input
                  required
                  type="text"
                  value={candName}
                  onChange={(e) => setCandName(e.target.value)}
                  placeholder="e.g. Liam Sterling"
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-805 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Target Role Position *</label>
                <input
                  required
                  type="text"
                  value={candRole}
                  onChange={(e) => setCandRole(e.target.value)}
                  placeholder="e.g. Senior Backend Director"
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-805 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Funnel stage status</label>
                <select
                  value={candStatus}
                  onChange={(e) => setCandStatus(e.target.value as any)}
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-2 text-xs text-slate-850 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-350"
                >
                  <option value="APPLIED">Applied</option>
                  <option value="SCREENING">Screening</option>
                  <option value="INTERVIEWING">Interviewing</option>
                  <option value="OFFER_MADE">Offer Made</option>
                  <option value="HIRED">Hired</option>
                </select>
              </div>

              <div className="pt-2 flex space-x-2.5">
                <button
                  type="button"
                  onClick={() => setShowCandModal(false)}
                  className="flex-1 border border-slate-200 rounded-lg py-2.5 text-xs font-bold text-slate-705 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-850"
                >
                  Discard
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 text-white rounded-lg py-2.5 text-xs font-extrabold hover:bg-blue-700 transition"
                >
                  Add Candidate
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
