import React, { useState, useEffect } from 'react';
import { useHR } from '../../context/HRContext';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { 
  Users, 
  UserCheck, 
  UserMinus, 
  UserPlus, 
  Search, 
  Filter, 
  Download, 
  Upload, 
  Plus, 
  Edit2, 
  Trash2, 
  X,
  Eye
} from 'lucide-react';
import { Employee, EmployeeStatus } from '../../types';

export default function Employees() {
  const { employees, addEmployee, updateEmployee, deleteEmployee, addNotification } = useHR();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  // Search/Filters states
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDept, setSelectedDept] = useState('All');
  const [selectedLoc, setSelectedLoc] = useState('All');
  const [selectedStatus, setSelectedStatus] = useState('All');

  // Modal active states
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingEmp, setEditingEmp] = useState<Employee | null>(null);

  // Form Fields State
  const [formName, setFormName] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formDept, setFormDept] = useState('Engineering');
  const [formRole, setFormRole] = useState('');
  const [formLoc, setFormLoc] = useState('New York Office');
  const [formStatus, setFormStatus] = useState<EmployeeStatus>('ACTIVE');
  const [formSalary, setFormSalary] = useState(90000);

  // Sync core header search parameter
  useEffect(() => {
    const queryParam = searchParams.get('search');
    if (queryParam) {
      setSearchQuery(queryParam);
    }
  }, [searchParams]);

  // Aggregate Lists for Select Filters dynamically
  const departments = ['All', ...Array.from(new Set(employees.map(e => e.department)))];
  const locations = ['All', ...Array.from(new Set(employees.map(e => e.location)))];
  const statuses = ['All', 'ACTIVE', 'ON LEAVE', 'REMOTE'];

  // Handle Form Submission
  const handleAddNewEmployee = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName || !formEmail || !formRole) {
      addNotification('Please fill in Name, Email, and Job Title.', 'warning');
      return;
    }
    addEmployee({
      name: formName,
      email: formEmail,
      phone: formPhone || '(555) 012-3456',
      status: formStatus,
      department: formDept,
      role: formRole,
      manager: 'Sarah Jenkins',
      location: formLoc,
      salary: Number(formSalary) || 80000,
    });
    
    // Reset Form
    setFormName('');
    setFormEmail('');
    setFormPhone('');
    setFormRole('');
    setFormSalary(90000);
    setShowAddModal(false);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingEmp) {
      updateEmployee(editingEmp.id, {
        name: formName,
        email: formEmail,
        phone: formPhone,
        department: formDept,
        role: formRole,
        location: formLoc,
        status: formStatus,
        salary: Number(formSalary)
      });
      setShowEditModal(false);
      setEditingEmp(null);
    }
  };

  const openEditModal = (emp: Employee) => {
    setEditingEmp(emp);
    setFormName(emp.name);
    setFormEmail(emp.email);
    setFormPhone(emp.phone);
    setFormDept(emp.department);
    setFormRole(emp.role);
    setFormLoc(emp.location);
    setFormStatus(emp.status);
    setFormSalary(emp.salary);
    setShowEditModal(true);
  };

  // Filter Logic
  const filteredEmployees = employees.filter(emp => {
    const matchesSearch = emp.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          emp.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          emp.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          emp.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDept = selectedDept === 'All' || emp.department === selectedDept;
    const matchesLoc = selectedLoc === 'All' || emp.location === selectedLoc;
    const matchesStatus = selectedStatus === 'All' || emp.status === selectedStatus;
    
    return matchesSearch && matchesDept && matchesLoc && matchesStatus;
  });

  return (
    <div className="space-y-6">
      
      {/* HEADER BAR */}
      <div className="flex flex-col justify-between space-y-4 sm:flex-row sm:items-center sm:space-y-0">
        <div>
          <h1 className="text-xl font-extrabold tracking-tight text-slate-900 dark:text-white md:text-2xl">Employees</h1>
          <p className="text-xs font-semibold text-slate-400 dark:text-slate-500">Search profiles, administer status updates, and edit records</p>
        </div>
        <div className="flex space-x-2.5">
          <button 
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center space-x-2 rounded-lg bg-blue-600 px-4 py-2 text-xs font-black text-white hover:bg-blue-700 shadow-sm shadow-blue-500/10 transition"
          >
            <Plus className="h-4 w-4" />
            <span>Add New Employee</span>
          </button>
        </div>
      </div>

      {/* METRIC SUMMARIES GRID */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        
        {/* KPI 1 */}
        <div className="flex items-center justify-between rounded-xl border border-slate-100 bg-white p-4 shadow-sm dark:border-slate-805 dark:bg-slate-850">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Employees</span>
            <span className="text-xl font-extrabold text-slate-950 dark:text-white mt-1 block">1,248</span>
          </div>
          <div className="rounded-lg bg-blue-50 p-2 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400">
            <Users className="h-4 w-4" />
          </div>
        </div>

        {/* KPI 2 */}
        <div className="flex items-center justify-between rounded-xl border border-slate-100 bg-white p-4 shadow-sm dark:border-slate-805 dark:bg-slate-850">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Active Employees</span>
            <span className="text-xl font-extrabold text-slate-950 dark:text-white mt-1 block">1,150</span>
          </div>
          <div className="rounded-lg bg-emerald-50 p-2 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400">
            <UserCheck className="h-4 w-4" />
          </div>
        </div>

        {/* KPI 3 */}
        <div className="flex items-center justify-between rounded-xl border border-slate-100 bg-white p-4 shadow-sm dark:border-slate-805 dark:bg-slate-850">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">On Active Leave</span>
            <span className="text-xl font-extrabold text-slate-950 dark:text-white mt-1 block">42</span>
          </div>
          <div className="rounded-lg bg-amber-50 p-2 text-amber-600 dark:bg-amber-950/40 dark:text-amber-400">
            <UserMinus className="h-4 w-4" />
          </div>
        </div>

        {/* KPI 4 */}
        <div className="flex items-center justify-between rounded-xl border border-slate-100 bg-white p-4 shadow-sm dark:border-slate-805 dark:bg-slate-850">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">New Hires</span>
            <span className="text-xl font-extrabold text-slate-950 dark:text-white mt-1 block">18</span>
          </div>
          <div className="rounded-lg bg-purple-50 p-2 text-purple-600 dark:bg-purple-950/40 dark:text-purple-400">
            <UserPlus className="h-4 w-4" />
          </div>
        </div>

      </div>

      {/* FILTER CONTROL PANEL */}
      <div className="rounded-xl border border-slate-100 bg-white p-4 shadow-sm dark:border-slate-805 dark:bg-slate-850 space-y-4">
        
        {/* Search And Action row */}
        <div className="flex flex-col justify-between space-y-2 md:flex-row md:items-center md:space-y-0">
          <div className="relative w-full max-w-sm">
            <Search className="absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search via Name, Role, or ID..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-9 w-full rounded-lg border border-slate-200 bg-slate-50 pl-10 pr-4 text-xs font-semibold text-slate-800 transition focus:border-blue-500 focus:bg-white focus:outline-none dark:border-slate-800 dark:bg-slate-800 dark:text-slate-100"
            />
          </div>
          
          <div className="flex space-x-2">
            <button 
              onClick={() => addNotification('Employees database exported successfully to Excel CSV format.', 'success')}
              className="inline-flex h-9 items-center space-x-1.5 rounded-lg border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-750 transition"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Export CSV</span>
            </button>
            <button 
              onClick={() => addNotification('Import wizard activated. Choose a CSV structure to sync.', 'info')}
              className="inline-flex h-9 items-center space-x-1.5 rounded-lg border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-750 transition"
            >
              <Upload className="h-3.5 w-3.5" />
              <span>Import</span>
            </button>
          </div>
        </div>

        {/* Multi-parameter select lists */}
        <div className="grid gap-3 sm:grid-cols-3">
          
          <div>
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Filter Department</label>
            <select
              value={selectedDept}
              onChange={(e) => setSelectedDept(e.target.value)}
              className="mt-1 h-9 w-full rounded-md border border-slate-200 bg-slate-50/50 px-2.5 text-xs text-slate-700 font-bold dark:border-slate-800 dark:bg-slate-800 dark:text-slate-300"
            >
              {departments.map((dept) => (
                <option key={dept} value={dept}>{dept}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Filter Location</label>
            <select
              value={selectedLoc}
              onChange={(e) => setSelectedLoc(e.target.value)}
              className="mt-1 h-9 w-full rounded-md border border-slate-200 bg-slate-50/50 px-2.5 text-xs text-slate-700 font-bold dark:border-slate-800 dark:bg-slate-800 dark:text-slate-300"
            >
              {locations.map((loc) => (
                <option key={loc} value={loc}>{loc}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Filter Status</label>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="mt-1 h-9 w-full rounded-md border border-slate-200 bg-slate-50/50 px-2.5 text-xs text-slate-700 font-bold dark:border-slate-800 dark:bg-slate-800 dark:text-slate-300"
            >
              {statuses.map((st) => (
                <option key={st} value={st}>{st}</option>
              ))}
            </select>
          </div>

        </div>

      </div>

      {/* REPOSITORY DATA GRID */}
      <div className="overflow-hidden rounded-xl border border-slate-100 bg-white shadow-sm dark:border-slate-805 dark:bg-slate-850">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-50 bg-slate-50/70 text-[11px] font-extrabold uppercase tracking-widest text-slate-400 dark:border-slate-800 dark:bg-slate-800/40">
                <th className="px-6 py-3.5">Employee</th>
                <th className="px-6 py-3.5">ID &amp; DEPT</th>
                <th className="px-6 py-3.5">STATUS</th>
                <th className="px-6 py-3.5">LOCATION</th>
                <th className="px-6 py-3.5">JOIN DATE</th>
                <th className="px-6 py-3.5 text-right">ACTIONS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/40">
              {filteredEmployees.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-xs font-semibold text-slate-400 dark:text-slate-500">
                    No active employees match the designated filter guidelines.
                  </td>
                </tr>
              ) : (
                filteredEmployees.map((emp) => (
                  <tr key={emp.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors">
                    
                    {/* Employee Core */}
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-3">
                        <img 
                          src={emp.avatar} 
                          alt={emp.name} 
                          className="h-9 w-9 rounded-full object-cover border border-slate-200 dark:border-slate-700" 
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <p className="text-xs font-black text-slate-800 dark:text-slate-100 leading-tight">
                            {emp.name}
                          </p>
                          <p className="text-[10px] text-slate-400 dark:text-slate-500">{emp.email}</p>
                        </div>
                      </div>
                    </td>

                    {/* ID & Dept */}
                    <td className="px-6 py-4">
                      <div>
                        <span className="font-mono text-xs font-bold text-slate-700 dark:text-slate-300">
                          {emp.id}
                        </span>
                        <div className="text-[10px] text-slate-500 dark:text-slate-400 leading-none mt-0.5">
                          {emp.department} &bull; <span className="font-semibold">{emp.role}</span>
                        </div>
                      </div>
                    </td>

                    {/* Status badge */}
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[9px] font-extrabold tracking-wide uppercase ${
                        emp.status === 'ACTIVE'
                          ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-400'
                          : emp.status === 'ON LEAVE'
                          ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400'
                          : emp.status === 'REMOTE'
                          ? 'bg-sky-50 text-sky-700 dark:bg-sky-950/30 dark:text-sky-400'
                          : 'bg-rose-50 text-rose-700 dark:bg-rose-950/30 dark:text-rose-400'
                      }`}>
                        {emp.status}
                      </span>
                    </td>

                    {/* Location */}
                    <td className="px-6 py-4">
                      <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                        {emp.location}
                      </span>
                    </td>

                    {/* Join Date */}
                    <td className="px-6 py-4">
                      <span className="text-xs text-slate-400 dark:text-slate-400 font-semibold">
                        {emp.joinDate}
                      </span>
                    </td>

                    {/* Actions tools element */}
                    <td className="px-6 py-4 text-right space-x-2">
                      <button 
                        onClick={() => navigate(`/employees/${emp.id}`)}
                        title="View Detailed Eleanor Profile"
                        className="inline-flex h-7 w-7 items-center justify-center rounded-md border border-slate-100 bg-white text-slate-400 hover:bg-slate-50 hover:text-slate-800 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-400 dark:hover:text-white"
                      >
                        <Eye className="h-3.5 w-3.5" />
                      </button>
                      <button 
                        onClick={() => openEditModal(emp)}
                        title="Amend Details"
                        className="inline-flex h-7 w-7 items-center justify-center rounded-md border border-slate-100 bg-white text-slate-400 hover:bg-slate-50 hover:text-blue-600 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-400 dark:hover:text-sky-400"
                      >
                        <Edit2 className="h-3.5 w-3.5" />
                      </button>
                      <button 
                        disabled={emp.id === 'EMP-8829'} // Cannot delete Eleanor as core showcase
                        onClick={() => {
                          if (window.confirm(`Are you absolutely sure you want to terminate/remove employee ${emp.name}?`)) {
                            deleteEmployee(emp.id);
                          }
                        }}
                        title={emp.id === 'EMP-8829' ? 'Showcase Eleanor cannot be deleted' : 'Process Termination'}
                        className="inline-flex h-7 w-7 items-center justify-center rounded-md border border-slate-100 bg-white text-slate-400 hover:bg-slate-50 hover:text-rose-600 disabled:opacity-30 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-400 dark:hover:text-rose-400"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </td>

                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* PAGINATION PANEL FOOTER */}
        <div className="flex items-center justify-between border-t border-slate-100 px-6 py-4 dark:border-slate-800">
          <p className="text-[11px] font-semibold text-slate-400 dark:text-slate-500">
            Showing <span className="font-bold text-slate-700 dark:text-slate-300">1-{filteredEmployees.length}</span> of <span className="font-bold text-slate-700 dark:text-slate-300">{filteredEmployees.length}</span> candidates
          </p>
          <div className="flex space-x-1">
            <button className="rounded border border-slate-200 px-2.5 py-1 text-[10px] font-bold text-slate-500 hover:bg-slate-50 dark:border-slate-800 dark:text-slate-400" disabled>Previous</button>
            <button className="bg-blue-600 rounded px-2.5 py-1 text-[10px] font-bold text-white shadow">1</button>
            <button className="rounded border border-slate-200 px-2.5 py-1 text-[10px] font-bold text-slate-500 hover:bg-slate-50 dark:border-slate-800 dark:text-slate-400" disabled>Next</button>
          </div>
        </div>

      </div>

      {/* FORM MODAL: DRAFT ADD EMPLOYEE */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-lg rounded-xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-slate-100 uppercase tracking-wider">Register Corporate Employee</h3>
              <button onClick={() => setShowAddModal(false)} className="rounded p-1 hover:bg-slate-100 dark:hover:bg-slate-800">
                <X className="h-4 w-4 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleAddNewEmployee} className="mt-4 grid gap-4 grid-cols-2">
              
              <div className="col-span-2">
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Employee Full Name *</label>
                <input
                  required
                  type="text"
                  placeholder="e.g. Eleanor Vance"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-850 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Professional Email *</label>
                <input
                  required
                  type="email"
                  placeholder="eleanor@enterprise.co"
                  value={formEmail}
                  onChange={(e) => setFormEmail(e.target.value)}
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-850 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Personal Phone Number</label>
                <input
                  type="text"
                  placeholder="(555) 123-4567"
                  value={formPhone}
                  onChange={(e) => setFormPhone(e.target.value)}
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-850 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Assigned Department</label>
                <select
                  value={formDept}
                  onChange={(e) => setFormDept(e.target.value)}
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-2 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-850 dark:text-slate-100"
                >
                  <option value="Engineering">Engineering</option>
                  <option value="Marketing">Marketing</option>
                  <option value="Sales">Sales</option>
                  <option value="Finance">Finance</option>
                  <option value="HR & Admin">HR &amp; Admin</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Designated Role *</label>
                <input
                  required
                  type="text"
                  placeholder="e.g. Senior Product Designer"
                  value={formRole}
                  onChange={(e) => setFormRole(e.target.value)}
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-850 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Geographic Office</label>
                <input
                  type="text"
                  placeholder="e.g. New York Office"
                  value={formLoc}
                  onChange={(e) => setFormLoc(e.target.value)}
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-850 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Annual Salary (USD)</label>
                <input
                  type="number"
                  value={formSalary}
                  onChange={(e) => setFormSalary(Number(e.target.value))}
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-850 dark:text-slate-100"
                />
              </div>

              <div className="col-span-2">
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Operating Status</label>
                <select
                  value={formStatus}
                  onChange={(e) => setFormStatus(e.target.value as EmployeeStatus)}
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-2 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-850"
                >
                  <option value="ACTIVE">ACTIVE</option>
                  <option value="ON LEAVE">ON LEAVE</option>
                  <option value="REMOTE">REMOTE</option>
                </select>
              </div>

              <div className="col-span-2 pt-4 flex space-x-2.5">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 border border-slate-200 rounded-lg py-2.5 text-xs font-bold text-slate-700 hover:bg-slate-50 dark:border-slate-80%"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 text-white rounded-lg py-2.5 text-xs font-extrabold hover:bg-blue-700"
                >
                  Register Profile
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* FORM MODAL: EDIT EMPLOYEE */}
      {showEditModal && editingEmp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-lg rounded-xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-slate-100 uppercase tracking-wider">Amend Employee Details</h3>
              <button onClick={() => setShowEditModal(false)} className="rounded p-1 hover:bg-slate-100 dark:hover:bg-slate-800">
                <X className="h-4 w-4 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleEditSubmit} className="mt-4 grid gap-4 grid-cols-2">
              
              <div className="col-span-2">
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Employee Full Name *</label>
                <input
                  required
                  type="text"
                  placeholder="e.g. Eleanor Vance"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-850 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Professional Email *</label>
                <input
                  required
                  type="email"
                  value={formEmail}
                  onChange={(e) => setFormEmail(e.target.value)}
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-850 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Personal Phone Number</label>
                <input
                  type="text"
                  value={formPhone}
                  onChange={(e) => setFormPhone(e.target.value)}
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-850"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Assigned Department</label>
                <select
                  value={formDept}
                  onChange={(e) => setFormDept(e.target.value)}
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-2 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-850"
                >
                  <option value="Engineering">Engineering</option>
                  <option value="Marketing">Marketing</option>
                  <option value="Sales">Sales</option>
                  <option value="Finance">Finance</option>
                  <option value="HR & Admin">HR &amp; Admin</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Designated Role *</label>
                <input
                  required
                  type="text"
                  value={formRole}
                  onChange={(e) => setFormRole(e.target.value)}
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-850 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Geographic Office</label>
                <input
                  type="text"
                  value={formLoc}
                  onChange={(e) => setFormLoc(e.target.value)}
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-850 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Annual Salary (USD)</label>
                <input
                  type="number"
                  value={formSalary}
                  onChange={(e) => setFormSalary(Number(e.target.value))}
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-800"
                />
              </div>

              <div className="col-span-2">
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Operating Status</label>
                <select
                  value={formStatus}
                  onChange={(e) => setFormStatus(e.target.value as EmployeeStatus)}
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-2 text-xs text-slate-800"
                >
                  <option value="ACTIVE">ACTIVE</option>
                  <option value="ON LEAVE">ON LEAVE</option>
                  <option value="REMOTE">REMOTE</option>
                </select>
              </div>

              <div className="col-span-2 pt-4 flex space-x-2.5">
                <button
                  type="button"
                  onClick={() => { setShowEditModal(false); setEditingEmp(null); }}
                  className="flex-1 border border-slate-200 rounded-lg py-2.5 text-xs font-bold text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 text-white rounded-lg py-2.5 text-xs font-extrabold hover:bg-blue-700"
                >
                  Apply Amendments
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
