import React, { useState } from 'react';
import { useHR } from '../../context/HRContext';
import { 
  Calendar, 
  CheckCircle, 
  XCircle, 
  Eye, 
  HelpCircle,
  Plus,
  AlertCircle,
  ChevronLeft,
  ChevronRight,
  MoreVertical,
  X
} from 'lucide-react';
import { LeaveRequest } from '../../types';

export default function Leave() {
  const { 
    leaveRequests, 
    updateLeaveRequestStatus, 
    addLeaveRequest, 
    employees, 
    addNotification 
  } = useHR();
  
  const [showApplyModal, setShowApplyModal] = useState(false);
  const [applyEmpName, setApplyEmpName] = useState('Eleanor Vance');
  const [applyType, setApplyType] = useState<'Annual Leave' | 'Sick Leave' | 'Casual Leave' | 'Personal Leave' | 'Parental Leave'>('Annual Leave');
  const [applyReason, setApplyReason] = useState('');
  const [applyDuration, setApplyDuration] = useState('3 Days');
  const [applyDates, setApplyDates] = useState('Nov 20 - Nov 23, 2026');

  const handleApplySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!applyReason) {
      addNotification('Please enter a brief reason.', 'warning');
      return;
    }
    addLeaveRequest({
      employeeName: applyEmpName,
      employeeAvatar: employees.find(emp => emp.name === applyEmpName)?.avatar || 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
      leaveType: applyType,
      reason: applyReason,
      dates: applyDates,
      duration: applyDuration
    });
    setApplyReason('');
    setShowApplyModal(false);
  };

  // Balance Metrics (radial percentages mapped exactly to Screen 5)
  const balances = [
    { type: 'Annual', used: 18, total: 24, percent: 75, color: 'stroke-blue-600 dark:stroke-blue-500' },
    { type: 'Sick', used: 8, total: 10, percent: 80, color: 'stroke-emerald-600 dark:stroke-emerald-500' },
    { type: 'Casual', used: 3, total: 5, percent: 60, color: 'stroke-indigo-600 dark:stroke-indigo-500' },
    { type: 'Personal', used: 2, total: 5, percent: 40, color: 'stroke-pink-600 dark:stroke-pink-400' },
    { type: 'Parental', used: 0, total: 0, percent: 100, color: 'stroke-slate-400' }
  ];

  // Interactive approves
  const handleApprove = (id: string) => {
    updateLeaveRequestStatus(id, 'APPROVED');
  };

  const handleReject = (id: string) => {
    updateLeaveRequestStatus(id, 'REJECTED');
  };

  // Calendar days grid mimicking Screen 5 Calendar Overlay (October 2026)
  const calendarDays = [
    { num: '27', overlap: false, holiday: false }, { num: '28', overlap: false, holiday: false }, { num: '29', overlap: false, holiday: false }, { num: '30', overlap: false, holiday: false }, { num: '31', overlap: false, holiday: false },
    { num: '1', overlap: false, holiday: false }, { num: '2', overlap: false, holiday: false }, { num: '3', overlap: false, holiday: false }, { num: '4', overlap: false, holiday: false }, { num: '5', overlap: false, holiday: false }, { num: '6', overlap: false, holiday: false },
    { num: '7', overlap: false, holiday: true }, { num: '8', overlap: true, holiday: false }, { num: '9', overlap: true, holiday: false }, { num: '10', overlap: false, holiday: false }, { num: '11', overlap: false, holiday: false }, { num: '12', overlap: false, holiday: false },
    { num: '13', overlap: true, holiday: false }, { num: '14', overlap: false, holiday: false }, { num: '15', overlap: false, holiday: false }, { num: '16', overlap: false, holiday: false }, { num: '17', overlap: false, holiday: false }, { num: '18', overlap: false, holiday: false },
    { num: '19', overlap: true, holiday: false }, { num: '20', overlap: true, holiday: false }, { num: '21', overlap: false, holiday: false }, { num: '22', overlap: false, holiday: false }, { num: '23', overlap: false, holiday: false }, { num: '24', overlap: false, holiday: false },
    { num: '25', overlap: false, holiday: false }, { num: '26', overlap: false, holiday: false }, { num: '27', overlap: false, holiday: false }, { num: '28', overlap: false, holiday: false }, { num: '29', overlap: false, holiday: false }, { num: '30', overlap: false, holiday: false },
    { num: '31', overlap: false, holiday: false }, { num: '1', overlap: false, holiday: false }, { num: '2', overlap: false, holiday: false }, { num: '3', overlap: false, holiday: false }, { num: '4', overlap: false, holiday: false }, { num: '5', overlap: false, holiday: false }, { num: '6', overlap: false, holiday: false }
  ];

  const pendingApprovals = leaveRequests.filter(r => r.status === 'PENDING');

  return (
    <div className="space-y-6">
      
      {/* HEADER BAR */}
      <div className="flex flex-col justify-between space-y-3 sm:flex-row sm:items-center sm:space-y-0">
        <div>
          <h1 className="text-xl font-extrabold tracking-tight text-slate-900 dark:text-white md:text-2xl">Leave Management</h1>
          <p className="text-xs font-semibold text-slate-400 dark:text-slate-500">Track team availability, configure leave balances, and review active requests</p>
        </div>
        <button
          onClick={() => setShowApplyModal(true)}
          className="inline-flex h-9 items-center space-x-1.5 rounded-lg bg-blue-600 px-4 text-xs font-black text-white hover:bg-blue-700 shadow shadow-blue-500/10 transition"
        >
          <Plus className="h-4 w-4" />
          <span>Apply Holiday Leave</span>
        </button>
      </div>

      {/* RADIAL LEAVE BALANCES ROW (Matches Screen 5) */}
      <div className="grid gap-4 grid-cols-2 lg:grid-cols-5">
        {balances.map((bal, idx) => (
          <div key={idx} className="rounded-xl border border-slate-100 bg-white p-4 shadow-sm text-center dark:border-slate-805 dark:bg-slate-850 flex flex-col items-center">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{bal.type}</span>
            
            <div className="relative flex h-18 w-18 items-center justify-center my-3">
              <svg className="absolute transform -rotate-90" width="72" height="72">
                <circle cx="36" cy="36" r="28" stroke="currentColor" className="text-slate-100 dark:text-slate-800" strokeWidth="5.5" fill="transparent" />
                <circle cx="36" cy="36" r="28" stroke="currentColor" className={`${bal.color} transition-all duration-300`} strokeWidth="5.5" fill="transparent"
                  strokeDasharray={175.8}
                  strokeDashoffset={175.8 - (175.8 * bal.percent) / 100} 
                />
              </svg>
              <span className="text-xs font-black text-slate-900 dark:text-white leading-none">
                {bal.used}/{bal.total} <br/> <span className="text-[8px] font-semibold text-slate-400">Days</span>
              </span>
            </div>

            <p className="text-[10px] font-bold text-slate-400 leading-tight">
              Radial Progress {bal.percent}% <br /> 
              <span className="text-slate-700 dark:text-slate-350">{bal.total - bal.used} days remaining</span>
            </p>
          </div>
        ))}
      </div>

      {/* CORE ACTIVE REQUESTS & PLANNING GRID */}
      <div className="grid gap-6 lg:grid-cols-3">
        
        {/* Active Leave Requests list */}
        <div className="space-y-4 lg:col-span-2">
          
          <div className="rounded-xl border border-slate-100 bg-white p-4 shadow-sm dark:border-slate-805 dark:bg-slate-850 flex items-center justify-between">
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-400">Active Leave Requests</h3>
            <span className="text-[10px] bg-slate-100 text-slate-650 px-2 py-0.5 rounded-full font-bold dark:bg-slate-800 dark:text-slate-400">All Requests</span>
          </div>

          <div className="overflow-hidden rounded-xl border border-slate-100 bg-white shadow-sm dark:border-slate-805 dark:bg-slate-850">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-left">
                <thead>
                  <tr className="border-b border-slate-100 bg-slate-50/70 text-[10px] font-extrabold uppercase tracking-widest text-slate-400 dark:border-slate-800 dark:bg-slate-800/40">
                    <th className="px-6 py-3.5">Employee</th>
                    <th className="px-6 py-3.5">Leave Type</th>
                    <th className="px-6 py-3.5">Reason</th>
                    <th className="px-6 py-3.5">Dates Target</th>
                    <th className="px-6 py-3.5">Duration</th>
                    <th className="px-6 py-3.5">Status</th>
                    <th className="px-6 py-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs font-semibold dark:divide-slate-800/40">
                  {leaveRequests.map((req) => (
                    <tr key={req.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/10">
                      
                      <td className="px-6 py-3.5">
                        <div className="flex items-center space-x-2.5">
                          <img src={req.employeeAvatar} alt="Emp" className="h-7 w-7 rounded-full object-cover" />
                          <span className="font-extrabold text-slate-800 dark:text-slate-250 leading-tight">{req.employeeName}</span>
                        </div>
                      </td>

                      <td className="px-6 py-3.5 text-slate-600 dark:text-slate-400">{req.leaveType}</td>
                      <td className="px-6 py-3.5 text-slate-400 dark:text-slate-500 font-medium max-w-xs truncate">{req.reason}</td>
                      <td className="px-6 py-3.5 text-slate-600 dark:text-slate-400">{req.dates}</td>
                      <td className="px-6 py-3.5 text-slate-600 dark:text-slate-450">{req.duration}</td>
                      
                      <td className="px-6 py-3.5">
                        <span className={`inline-flex rounded-full px-2 py-0.5 text-[9px] font-black uppercase ${
                          req.status === 'APPROVED'
                            ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30'
                            : req.status === 'PENDING'
                            ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/30 animate-pulse'
                            : 'bg-rose-50 text-rose-700 dark:bg-rose-950/30'
                        }`}>
                          {req.status}
                        </span>
                      </td>

                      <td className="px-6 py-3.5 text-right space-x-1">
                        {req.status === 'PENDING' ? (
                          <>
                            <button
                              onClick={() => handleApprove(req.id)}
                              title="Approve Leave and Deduct Balance"
                              className="rounded p-1 bg-emerald-50 text-emerald-600 hover:bg-emerald-100 dark:bg-emerald-950/20"
                            >
                              <CheckCircle className="h-3.5 w-3.5" />
                            </button>
                            <button
                              onClick={() => handleReject(req.id)}
                              title="Decline request"
                              className="rounded p-1 bg-rose-50 text-rose-600 hover:bg-rose-100 dark:bg-rose-950/20"
                            >
                              <XCircle className="h-3.5 w-3.5" />
                            </button>
                          </>
                        ) : (
                          <span className="text-[10px] text-slate-400 font-medium">Archived</span>
                        )}
                      </td>

                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>

        {/* RIGHT AREA SIDEBAR */}
        <div className="space-y-6">
          
          {/* Team Availability CSS Calendar */}
          <div className="rounded-xl border border-slate-100 bg-white p-5 shadow-sm dark:border-slate-805 dark:bg-slate-850">
            <div className="flex items-center justify-between border-b border-slate-50 pb-3 dark:border-slate-800">
              <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-400">Team Availability</h4>
              <div className="flex items-center space-x-2 text-xs font-extrabold text-slate-800 dark:text-slate-350">
                <ChevronLeft className="h-3.5 w-3.5 text-slate-400 cursor-pointer" />
                <span>October 2026</span>
                <ChevronRight className="h-3.5 w-3.5 text-slate-400 cursor-pointer" />
              </div>
            </div>
            
            {/* Days row header */}
            <div className="grid grid-cols-7 gap-1 mt-4 text-center text-[10px] font-black text-slate-400">
              {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((d, i) => <div key={i}>{d}</div>)}
            </div>

            {/* October Calendar Block layout */}
            <div className="grid grid-cols-7 gap-1 mt-2 text-center text-[11px] font-bold">
              {calendarDays.map((c, i) => (
                <div
                  key={i}
                  className={`py-1.5 rounded-md flex items-center justify-center cursor-pointer transition ${
                    c.holiday
                      ? 'bg-rose-100 text-rose-700 dark:bg-rose-950/50 dark:text-rose-400'
                      : c.overlap
                      ? 'bg-blue-600 text-white font-extrabold shadow-sm'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50'
                  }`}
                >
                  {c.num}
                </div>
              ))}
            </div>

            {/* Legends layout */}
            <div className="mt-4 flex items-center justify-between text-[9px] font-bold text-slate-400 pt-3 border-t border-slate-50 dark:border-slate-800">
              <span className="flex items-center"><span className="h-2 w-2 rounded bg-blue-600 mr-1" /> Absence Overlaps</span>
              <span className="flex items-center"><span className="h-2 w-2 rounded bg-rose-100 mr-1" /> Public Holidays</span>
            </div>
          </div>

          {/* Pending Approvals queue */}
          {pendingApprovals.length > 0 && (
            <div className="rounded-xl border border-slate-100 bg-white p-5 shadow-sm dark:border-slate-805 dark:bg-slate-850">
              <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-400 mb-3 pb-2 border-b border-slate-50 dark:border-slate-800">
                Pending Approvals queue
              </h4>
              <div className="space-y-3">
                {pendingApprovals.map((req, idx) => (
                  <div key={req.id} className="flex items-center justify-between border-b border-slate-50 pb-2.5 last:border-0 last:pb-0 dark:border-slate-800/40">
                    <div className="flex items-center space-x-2.5">
                      <span className="text-[10px] font-bold rounded bg-sky-50 px-1.5 py-0.5 text-sky-700">{idx + 1}</span>
                      <div>
                        <p className="text-xs font-black text-slate-800 dark:text-slate-200">{req.employeeName}</p>
                        <p className="text-[9px] text-slate-400 font-semibold">{req.leaveType} &bull; {req.duration}</p>
                      </div>
                    </div>
                    <div className="flex space-x-1">
                      <button onClick={() => handleApprove(req.id)} className="h-6 w-6 rounded bg-emerald-50 text-emerald-600 flex items-center justify-center hover:bg-emerald-100 dark:bg-emerald-950/20"><CheckCircle className="h-3.5 w-3.5" /></button>
                      <button onClick={() => handleReject(req.id)} className="h-6 w-6 rounded bg-rose-50 text-rose-600 flex items-center justify-center hover:bg-rose-100 dark:bg-rose-950/20"><XCircle className="h-3.5 w-3.5" /></button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Policy Guidelines block */}
          <div className="rounded-xl border border-slate-100 bg-white p-5 shadow-sm dark:border-slate-805 dark:bg-slate-850 space-y-3">
            <div className="flex items-center space-x-2">
              <HelpCircle className="h-4 w-4 text-slate-400" />
              <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">Leave Policy summary</span>
            </div>
            <ul className="text-[10px] text-slate-400 dark:text-slate-500 space-y-2 list-disc pl-4 font-semibold leading-relaxed">
              <li>Key leave policy guidelines are permanent to review inside individual department manuals.</li>
              <li>Leave applications must map to direct supervisor approvals.</li>
              <li>Unused casual balances do not carry over to consecutive cycles.</li>
              <li>Direct medical certificates are mandatory on sick events exceeding 3 consecutive slots.</li>
            </ul>
          </div>

        </div>

      </div>

      {/* MODAL Apply Leave */}
      {showApplyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-[2px] p-4">
          <div className="w-full max-w-md rounded-xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-slate-100 uppercase tracking-widest">Apply Holiday Leave</h3>
              <button onClick={() => setShowApplyModal(false)} className="rounded p-1 hover:bg-slate-100 dark:hover:bg-slate-800">
                <X className="h-4 w-4 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleApplySubmit} className="mt-4 space-y-4">
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Employee Claimant</label>
                <select
                  value={applyEmpName}
                  onChange={(e) => setApplyEmpName(e.target.value)}
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-2 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-850 dark:text-slate-100"
                >
                  {employees.map(emp => <option key={emp.id} value={emp.name}>{emp.name}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Leave Category type</label>
                <select
                  value={applyType}
                  onChange={(e) => setApplyType(e.target.value as any)}
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-2 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-850 dark:text-slate-100"
                >
                  <option value="Annual Leave">Annual Leave</option>
                  <option value="Sick Leave">Sick Leave</option>
                  <option value="Casual Leave">Casual Leave</option>
                  <option value="Personal Leave">Personal Leave</option>
                  <option value="Parental Leave">Parental Leave</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Timeline dates</label>
                <input
                  type="text"
                  value={applyDates}
                  onChange={(e) => setApplyDates(e.target.value)}
                  placeholder="Nov 20 - Nov 23, 2026"
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-850 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Duration Days</label>
                <input
                  type="text"
                  value={applyDuration}
                  onChange={(e) => setApplyDuration(e.target.value)}
                  placeholder="e.g. 3 Days"
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-850 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Brief justification reason *</label>
                <input
                  required
                  type="text"
                  value={applyReason}
                  onChange={(e) => setApplyReason(e.target.value)}
                  placeholder="e.g. Vacation with relatives"
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-850 dark:text-slate-100"
                />
              </div>

              <div className="pt-2 flex space-x-2.5">
                <button
                  type="button"
                  onClick={() => setShowApplyModal(false)}
                  className="flex-1 border border-slate-200 rounded-lg py-2.5 text-xs font-bold text-slate-700 hover:bg-slate-50"
                >
                  Discard
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 text-white rounded-lg py-2.5 text-xs font-extrabold hover:bg-blue-700"
                >
                  Register Application
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
