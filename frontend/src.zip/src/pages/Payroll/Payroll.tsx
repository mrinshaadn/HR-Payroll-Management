import React, { useState } from 'react';
import { useHR } from '../../context/HRContext';
import { 
  DollarSign, 
  TrendingUp, 
  Clock, 
  Percent, 
  HelpCircle, 
  Download, 
  CheckCircle,
  Play,
  RotateCcw,
  CheckCircle2,
  Lock,
  ArrowRight,
  Plus,
  X
} from 'lucide-react';

export default function Payroll() {
  const { 
    employees, 
    loans, 
    addLoan, 
    currentPayCycleProgress, 
    payCycleStep, 
    advancePayCycleStep, 
    resetPayCycle, 
    addNotification 
  } = useHR();

  const [showLoanModal, setShowLoanModal] = useState(false);
  const [loanEmpName, setLoanEmpName] = useState('Eleanor Vance');
  const [loanAmount, setLoanAmount] = useState(5000);
  const [loanTenure, setLoanTenure] = useState(12);

  // Auto Calculations
  let totalDistributedBase = 0;
  let totalNetPayable = 0;

  const payrollRows = employees.map(emp => {
    const base = emp.salary / 12; // Monthly slice
    const allowances = emp.department === 'Sales' ? 850 : 250;
    const deductions = base * 0.12; // e.g. 12% standard taxes/benefits
    const overtimePay = emp.metrics.attendanceRate > 96 ? 450 : 0;
    const net = base + allowances - deductions + overtimePay;

    totalDistributedBase += base;
    totalNetPayable += net;

    return {
      ...emp,
      base,
      allowances,
      deductions,
      overtimePay,
      net
    };
  });

  const handleExportPayrollExcel = () => {
    addNotification('Compensation statement ledger successfully compiled and exported to CSV.', 'success');
  };

  const handleAddLoanSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addLoan({
      employeeName: loanEmpName,
      employeeAvatar: employees.find(emp => emp.name === loanEmpName)?.avatar || 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
      totalAmount: loanAmount,
      remainingAmount: loanAmount,
      monthsRemaining: loanTenure
    });
    setShowLoanModal(false);
  };

  // Pay Cycle visual milestones checks
  const steps = [
    { num: 1, text: 'Employee Clock Audit' },
    { num: 2, text: 'Overtime & Allowances Audit' },
    { num: 3, text: 'Benefit & Tax Deductions' },
    { num: 4, text: 'Board Review & Signoff' },
    { num: 5, text: 'Disburse Salaries' },
    { num: 6, text: 'Complete & Lock Ledger' }
  ];

  return (
    <div className="space-y-6">
      
      {/* HEADER ROW */}
      <div className="flex flex-col justify-between space-y-3 sm:flex-row sm:items-center sm:space-y-0">
        <div>
          <h1 className="text-xl font-extrabold tracking-tight text-slate-900 dark:text-white md:text-2xl">Payroll Ledger</h1>
          <p className="text-xs font-semibold text-slate-400 dark:text-slate-500">Formulate compensations, administer loan deductions, and regulate pay cycles</p>
        </div>
        <div className="flex space-x-2">
          <button
            onClick={handleExportPayrollExcel}
            className="inline-flex h-9 items-center space-x-1.5 rounded-lg border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Compensation Sheet (CSV)</span>
          </button>
        </div>
      </div>

      {/* METRIC SUMMARIES */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        
        <div className="flex items-center justify-between rounded-xl border border-slate-100 bg-white p-4 shadow-sm dark:border-slate-805 dark:bg-slate-850">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Total Distributed</span>
            <div className="flex items-baseline space-x-2 mt-1">
              <span className="text-xl font-black text-slate-950 dark:text-white">${(totalDistributedBase * 12).toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
              <span className="text-[10px] font-bold text-emerald-500 flex items-center">&uarr; +5.4%</span>
            </div>
          </div>
          <div className="rounded-lg bg-blue-50 p-2 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400">
            <DollarSign className="h-4 w-4" />
          </div>
        </div>

        <div className="flex items-center justify-between rounded-xl border border-slate-100 bg-white p-4 shadow-sm dark:border-slate-805 dark:bg-slate-850">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Cycle Monthly cost</span>
            <div className="flex items-baseline space-x-2 mt-1">
              <span className="text-xl font-black text-slate-950 dark:text-white">${totalNetPayable.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
              <span className="text-[10px] font-bold text-emerald-500 flex items-center">&uarr; +3.4%</span>
            </div>
          </div>
          <div className="rounded-lg bg-emerald-50 p-2 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400">
            <TrendingUp className="h-4 w-4" />
          </div>
        </div>

        <div className="flex items-center justify-between rounded-xl border border-slate-100 bg-white p-4 shadow-sm dark:border-slate-805 dark:bg-slate-850">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Pending Disbursals</span>
            <span className="text-xl font-black text-slate-950 dark:text-white mt-1">$0.00</span>
          </div>
          <div className="rounded-lg bg-amber-50 p-2 text-amber-600 dark:bg-amber-950/40 dark:text-amber-400">
            <CheckCircle className="h-4 w-4" />
          </div>
        </div>

        <div className="flex items-center justify-between rounded-xl border border-slate-100 bg-white p-4 shadow-sm dark:border-slate-805 dark:bg-slate-850">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Overtime payout</span>
            <span className="text-xl font-black text-slate-950 dark:text-white mt-1">$18,290</span>
          </div>
          <div className="rounded-lg bg-purple-50 p-2 text-purple-600 dark:bg-purple-950/40 dark:text-purple-400">
            <Clock className="h-4 w-4" />
          </div>
        </div>

      </div>

      {/* DETAILED LEDGER CHART & TIMELINES */}
      <div className="grid gap-6 lg:grid-cols-3">
        
        {/* Left Side: Payroll Table Grid */}
        <div className="space-y-4 lg:col-span-2">
          
          <div className="rounded-xl border border-slate-100 bg-white p-4 shadow-sm dark:border-slate-805 dark:bg-slate-850 flex items-center justify-between">
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-400">Active Payroll Cycle Details</h3>
            <span className="text-[10px] font-mono font-bold text-blue-500 py-0.5 px-2 rounded-md bg-blue-50 dark:bg-blue-950/20">Nov pay period (15-30)</span>
          </div>

          <div className="overflow-hidden rounded-xl border border-slate-100 bg-white shadow-sm dark:border-slate-805 dark:bg-slate-850">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-left">
                <thead>
                  <tr className="border-b border-slate-100 bg-slate-50/70 text-[10px] font-extrabold uppercase tracking-widest text-slate-400 dark:border-slate-800 dark:bg-slate-800/40">
                    <th className="px-5 py-3.5">Employee</th>
                    <th className="px-5 py-3.5">Base Salary</th>
                    <th className="px-5 py-3.5">Allowances</th>
                    <th className="px-5 py-3.5">Deductions</th>
                    <th className="px-5 py-3.5">Overtime</th>
                    <th className="px-5 py-3.5 text-right">Net Payable</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs font-semibold dark:divide-slate-800/40">
                  {payrollRows.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/10">
                      
                      <td className="px-5 py-3.5">
                        <div className="flex items-center space-x-2.5">
                          <img src={p.avatar} alt="User" className="h-7.5 w-7.5 rounded-full object-cover" />
                          <div>
                            <p className="font-extrabold text-slate-850 dark:text-slate-100 leading-tight">{p.name}</p>
                            <p className="text-[9px] text-slate-400 font-mono leading-none mt-0.5">{p.id} &bull; {p.role}</p>
                          </div>
                        </div>
                      </td>

                      <td className="px-5 py-3.5 font-mono text-slate-700 dark:text-slate-300">
                        ${p.base.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </td>

                      <td className="px-5 py-3.5 font-mono text-emerald-600">
                        +${p.allowances.toLocaleString()}
                      </td>

                      <td className="px-5 py-3.5 font-mono text-rose-500">
                        -${p.deductions.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </td>

                      <td className="px-5 py-3.5 font-mono text-slate-500 dark:text-slate-400">
                        +${p.overtimePay}
                      </td>

                      <td className="px-5 py-3.5 text-right font-mono text-slate-900 font-black dark:text-white">
                        ${p.net.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </td>

                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>

        {/* Right Side: Step Progress Milestones & Outstanding Loans */}
        <div className="space-y-6">
          
          {/* Circular Step tracker */}
          <div className="rounded-xl border border-slate-100 bg-white p-5 shadow-sm dark:border-slate-805 dark:bg-slate-850">
            <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-400 mb-4 pb-2 border-b border-slate-50 dark:border-slate-800">
              Pay Cycle Processing Step
            </h4>
            
            <div className="flex flex-col items-center justify-center text-center p-2">
              <div className="relative flex h-20 w-20 items-center justify-center mb-4">
                <svg className="absolute transform -rotate-90" width="80" height="80">
                  <circle cx="40" cy="40" r="32" stroke="currentColor" className="text-slate-100 dark:text-slate-800" strokeWidth="6" fill="transparent" />
                  <circle cx="40" cy="40" r="32" stroke="currentColor" className="text-blue-600 dark:text-blue-400 transition-all duration-500" strokeWidth="6" fill="transparent"
                    strokeDasharray={201.1}
                    strokeDashoffset={201.1 - (201.1 * currentPayCycleProgress) / 100} 
                  />
                </svg>
                <span className="text-lg font-black text-slate-900 dark:text-white">{currentPayCycleProgress}%</span>
              </div>
              
              <h5 className="text-xs font-extrabold text-slate-800 dark:text-slate-350">
                Cycle Processing Steps checklist
              </h5>
              <p className="text-[10px] text-slate-400 font-medium">Status: Step {payCycleStep} of 6</p>
            </div>

            <div className="mt-4 space-y-2 text-xs font-semibold">
              {steps.map((st) => {
                const isCompleted = payCycleStep > st.num;
                const isActive = payCycleStep === st.num;

                return (
                  <div key={st.num} className={`p-2 rounded-lg flex items-center justify-between transition ${
                    isActive 
                      ? 'bg-blue-50 border border-blue-100 dark:bg-blue-950/20 dark:border-blue-950/40' 
                      : 'border border-transparent'
                  }`}>
                    <div className="flex items-center space-x-2.5">
                      {isCompleted ? (
                        <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                      ) : isActive ? (
                        <div className="h-3.5 w-3.5 rounded-full border-3 border-blue-600 animate-pulse" />
                      ) : (
                        <div className="h-3.5 w-3.5 rounded-full border-2 border-slate-200" />
                      )}
                      <span className={isCompleted ? 'text-slate-400 line-through' : 'text-slate-700 dark:text-slate-300'}>
                        {st.text}
                      </span>
                    </div>
                    {isActive && (
                      <span className="text-[8px] font-black uppercase text-blue-600 tracking-wider">Processing</span>
                    )}
                  </div>
                );
              })}
            </div>

            <div className="mt-5 pt-3 border-t border-slate-50 flex space-x-3 dark:border-slate-800">
              <button
                onClick={advancePayCycleStep}
                disabled={payCycleStep >= 6}
                className="flex-1 bg-slate-950 text-white rounded-lg py-2 text-xs font-extrabold hover:bg-slate-850 disabled:opacity-30 flex items-center justify-center space-x-1 dark:bg-blue-600 dark:hover:bg-blue-700"
              >
                <Play className="h-3 w-3" />
                <span>Advance step</span>
              </button>
              <button
                onClick={resetPayCycle}
                className="rounded-lg border border-slate-200 p-2 text-slate-400 hover:bg-slate-50 dark:border-slate-800"
                title="Restart Pay Cycle"
              >
                <RotateCcw className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Loans cards with add loan button */}
          <div className="rounded-xl border border-slate-100 bg-white p-5 shadow-sm dark:border-slate-805 dark:bg-slate-850 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-50 pb-3 dark:border-slate-800">
              <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-400">Employee Advanced Loans</h4>
              <button
                onClick={() => setShowLoanModal(true)}
                title="Register New Loans record"
                className="p-1 rounded bg-slate-50 text-slate-400 hover:bg-slate-100 dark:bg-slate-800/40"
              >
                <Plus className="h-3.5 w-3.5" />
              </button>
            </div>

            <div className="space-y-3">
              {loans.map((loan) => (
                <div key={loan.id} className="p-3 border border-slate-50 rounded-lg dark:border-slate-800/40 bg-slate-50/50 dark:bg-slate-800/10 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <img src={loan.employeeAvatar} alt="Emp" className="h-6 w-6 rounded-full object-cover" />
                      <span className="text-xs font-extrabold text-slate-800 dark:text-slate-250">{loan.employeeName}</span>
                    </div>
                    <span className="text-[10px] bg-sky-50 px-1.5 py-0.5 rounded font-black text-sky-700">{(loan.monthsRemaining ?? 12)} Months</span>
                  </div>
                  <div className="flex justify-between items-end text-xs font-semibold">
                    <div>
                      <p className="text-[10px] text-slate-400">Outstanding Principal</p>
                      <p className="text-slate-800 dark:text-white font-extrabold">${(loan.remainingAmount ?? loan.outstandingBalance ?? 0).toLocaleString()}</p>
                    </div>
                    <p className="text-[9px] text-slate-400 font-medium">Original Limit: ${(loan.totalAmount ?? loan.approvedAmount ?? 0).toLocaleString()}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

      {/* LOAN REGISTER MODAL */}
      {showLoanModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-[2px] p-4">
          <div className="w-full max-w-sm rounded-xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-slate-100 uppercase tracking-widest">Acknowledge Advanced Loan</h3>
              <button onClick={() => setShowLoanModal(false)} className="rounded p-1 hover:bg-slate-100 dark:hover:bg-slate-800">
                <X className="h-4 w-4 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleAddLoanSubmit} className="mt-4 space-y-4">
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Employee Claimant</label>
                <select
                  value={loanEmpName}
                  onChange={(e) => setLoanEmpName(e.target.value)}
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-2 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-850 dark:text-slate-100"
                >
                  {employees.map(emp => <option key={emp.id} value={emp.name}>{emp.name}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Total Borrowed Amount (USD) *</label>
                <input
                  required
                  type="number"
                  value={loanAmount}
                  onChange={(e) => setLoanAmount(Number(e.target.value))}
                  placeholder="e.g. 15000"
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-800 dark:border-slate-800"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Repayment Period Tenure (Months)</label>
                <input
                  type="number"
                  value={loanTenure}
                  onChange={(e) => setLoanTenure(Number(e.target.value))}
                  placeholder="e.g. 12"
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-800 dark:border-slate-800"
                />
              </div>

              <div className="pt-2 flex space-x-2.5">
                <button
                  type="button"
                  onClick={() => setShowLoanModal(false)}
                  className="flex-1 border border-slate-200 rounded-lg py-2.5 text-xs font-bold text-slate-700 hover:bg-slate-50"
                >
                  Discard
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 text-white rounded-lg py-2.5 text-xs font-extrabold hover:bg-blue-700"
                >
                  Disburse Loan
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
