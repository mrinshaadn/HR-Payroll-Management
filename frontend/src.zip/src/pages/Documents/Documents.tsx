import React, { useState } from 'react';
import { useHR } from '../../context/HRContext';
import { 
  FileText, 
  Download, 
  Upload, 
  Trash2, 
  Search, 
  Filter, 
  FileCheck, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  Plus, 
  X 
} from 'lucide-react';

export default function Documents() {
  const { documents, addDocument, deleteDocument, addNotification } = useHR();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [showUploadModal, setShowUploadModal] = useState(false);
  
  // Upload form states
  const [docName, setDocName] = useState('');
  const [docCategory, setDocCategory] = useState<'Offer Letters' | 'Contracts' | 'ID Proofs' | 'Certifications' | 'Tax Forms'>('Contracts');
  const [expiryDate, setExpiryDate] = useState('Dec 2026');

  // Stats calculation
  const totalDocs = documents.length;
  const activeDocs = documents.filter(d => d.status === 'Active').length;
  const expiringDocs = documents.filter(d => d.status === 'Expiring Soon').length;
  const expiredDocs = documents.filter(d => d.status === 'Expired').length;
  const missingDocs = documents.filter(d => d.status === 'Missing').length;

  const filteredDocs = documents.filter(doc => {
    const matchesSearch = doc.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          doc.ownerName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || doc.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleUploadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!docName.trim()) {
      addNotification('Please enter a document title.', 'warning');
      return;
    }

    addDocument({
      name: docName,
      category: docCategory,
      ownerName: 'Alex Rivera',
      ownerAvatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150',
      expiryDate,
      status: 'Active'
    });

    setDocName('');
    setShowUploadModal(false);
  };

  const handleDownload = (name: string) => {
    addNotification(`Downloading document: ${name}`, 'success');
  };

  const categories = ['All', 'Offer Letters', 'Contracts', 'ID Proofs', 'Certifications', 'Tax Forms'];

  return (
    <div className="space-y-6">
      
      {/* Header bar */}
      <div className="flex flex-col justify-between space-y-3 sm:flex-row sm:items-center sm:space-y-0">
        <div>
          <h1 className="text-xl font-extrabold tracking-tight text-slate-900 dark:text-white md:text-2xl">Secure Document Vault</h1>
          <p className="text-xs font-semibold text-slate-400 dark:text-slate-500">Store, manage, and audit employee credentials and company agreements</p>
        </div>
        <button
          onClick={() => setShowUploadModal(true)}
          className="inline-flex h-9 items-center space-x-1.5 rounded-lg bg-blue-600 px-4 text-xs font-extrabold text-white hover:bg-blue-700 shadow-sm transition"
        >
          <Upload className="h-3.5 w-3.5" />
          <span>Upload Document</span>
        </button>
      </div>

      {/* Vault Summary Cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        
        <div className="rounded-xl border border-slate-100 bg-white p-4 shadow-sm dark:border-slate-805 dark:bg-slate-850">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Vault Packages</span>
          <span className="text-2xl font-black text-slate-950 dark:text-white mt-1 block">{totalDocs}</span>
        </div>

        <div className="rounded-xl border border-slate-100 bg-white p-4 shadow-sm dark:border-slate-805 dark:bg-slate-850 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Active Packages</span>
            <span className="text-2xl font-black text-emerald-500 mt-1 block">{activeDocs}</span>
          </div>
          <div className="rounded-lg bg-emerald-50 p-2 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400">
            <CheckCircle className="h-4 w-4" />
          </div>
        </div>

        <div className="rounded-xl border border-slate-100 bg-white p-4 shadow-sm dark:border-slate-805 dark:bg-slate-850 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Expiring Soon</span>
            <span className="text-2xl font-black text-amber-500 mt-1 block">{expiringDocs}</span>
          </div>
          <div className="rounded-lg bg-amber-50 p-2 text-amber-600 dark:bg-amber-950/40 dark:text-amber-400">
            <Clock className="h-4 w-4" />
          </div>
        </div>

        <div className="rounded-xl border border-slate-100 bg-white p-4 shadow-sm dark:border-slate-805 dark:bg-slate-850 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Expired Logs</span>
            <span className="text-2xl font-black text-rose-500 mt-1 block">{expiredDocs}</span>
          </div>
          <div className="rounded-lg bg-rose-50 p-2 text-rose-600 dark:bg-rose-950/40" style={{ color: '#ef4444' }}>
            <AlertTriangle className="h-4 w-4" />
          </div>
        </div>

        <div className="rounded-xl border border-slate-100 bg-white p-4 shadow-sm dark:border-slate-805 dark:bg-slate-850 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Missing Dossiers</span>
            <span className="text-2xl font-black text-slate-500 mt-1 block">{missingDocs}</span>
          </div>
          <div className="rounded-lg bg-slate-100 p-2 text-slate-500 dark:bg-slate-800 dark:text-slate-400">
            <FileText className="h-4 w-4" />
          </div>
        </div>

      </div>

      {/* Search & Category Filter Controls */}
      <div className="flex flex-col space-y-3 md:flex-row md:items-center md:justify-between md:space-y-0 bg-white p-4 rounded-xl border border-slate-100 dark:border-slate-805 dark:bg-slate-850 shadow-sm">
        
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search by title or author..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="h-10 w-full rounded-md border border-slate-200 bg-slate-50 pl-10 pr-4 text-xs font-semibold text-slate-800 focus:border-blue-600 focus:bg-white focus:outline-none dark:border-slate-800 dark:bg-slate-800 dark:text-slate-100"
          />
        </div>

        {/* Filter categories tabs */}
        <div className="flex items-center space-x-1.5 overflow-x-auto">
          <Filter className="h-4 w-4 text-slate-450 mr-1 hidden md:block" />
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`rounded-lg px-3.5 py-1.5 text-[10px] font-black tracking-wider uppercase transition ${
                selectedCategory === cat
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-slate-50 text-slate-650 hover:bg-slate-100 dark:bg-slate-800 dark:text-slate-400 dark:hover:bg-slate-750'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

      </div>

      {/* Main Table Ledger */}
      <div className="overflow-hidden rounded-xl border border-slate-100 bg-white shadow-sm dark:border-slate-805 dark:bg-slate-850">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50/70 text-[10px] font-extrabold uppercase tracking-widest text-slate-400 dark:border-slate-800 dark:bg-slate-800/40">
                <th className="px-6 py-4">Document Title</th>
                <th className="px-6 py-4">Category</th>
                <th className="px-6 py-4">Owner / Signee</th>
                <th className="px-6 py-4">Sync Upload Date</th>
                <th className="px-6 py-4">Audit Expiry Date</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs font-bold text-slate-700 dark:divide-slate-800/40 dark:text-slate-300">
              {filteredDocs.length > 0 ? (
                filteredDocs.map((doc) => (
                  <tr key={doc.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/10 transition">
                    
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-3">
                        <FileText className="h-5 w-5 text-blue-500" />
                        <span className="text-slate-900 dark:text-white font-extrabold tracking-tight">{doc.name}</span>
                      </div>
                    </td>

                    <td className="px-6 py-4 text-slate-500 font-semibold">{doc.category}</td>

                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-2">
                        <img src={doc.ownerAvatar} alt="Owner" className="h-6 w-6 rounded-full object-cover" />
                        <span className="font-semibold text-slate-650 dark:text-slate-350">{doc.ownerName}</span>
                      </div>
                    </td>

                    <td className="px-6 py-4 text-slate-400 font-mono font-semibold">{doc.uploadDate}</td>
                    <td className="px-6 py-4 text-slate-450 font-mono font-semibold">{doc.expiryDate}</td>

                    <td className="px-6 py-4">
                      <span className={`inline-flex rounded-full px-2 py-0.5 text-[9px] font-black uppercase tracking-wider ${
                        doc.status === 'Active'
                          ? 'bg-emerald-50 text-emerald-700'
                          : doc.status === 'Expiring Soon'
                          ? 'bg-amber-50 text-amber-700'
                          : doc.status === 'Expired'
                          ? 'bg-rose-50 text-rose-700'
                          : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-400'
                      }`}>
                        {doc.status}
                      </span>
                    </td>

                    <td className="px-6 py-4 text-right space-x-1">
                      <button
                        onClick={() => handleDownload(doc.name)}
                        className="p-1.5 rounded hover:bg-blue-50 text-slate-400 hover:text-blue-600 transition"
                        title="Download Document"
                      >
                        <Download className="h-4.5 w-4.5" />
                      </button>
                      <button
                        onClick={() => deleteDocument(doc.id)}
                        className="p-1.5 rounded hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition"
                        title="Delete Package"
                      >
                        <Trash2 className="h-4.5 w-4.5" />
                      </button>
                    </td>

                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={7} className="px-6 py-8 text-center text-slate-450 font-semibold">
                    No documents found matching the current search parameters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* UPLOAD DOCUMENT MODAL */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-[2px] p-4">
          <div className="w-full max-w-sm rounded-xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-slate-100 uppercase tracking-widest">Upload Document Dossier</h3>
              <button onClick={() => setShowUploadModal(false)} className="rounded p-1 hover:bg-slate-100 dark:hover:bg-slate-800">
                <X className="h-4 w-4 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleUploadSubmit} className="mt-4 space-y-4">
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Document Title *</label>
                <input
                  required
                  type="text"
                  value={docName}
                  onChange={(e) => setDocName(e.target.value)}
                  placeholder="e.g. Non-Disclosure Agreement.pdf"
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Document Category</label>
                <select
                  value={docCategory}
                  onChange={(e) => setDocCategory(e.target.value as any)}
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-2 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-100"
                >
                  <option value="Contracts">Contracts & Agreements</option>
                  <option value="Offer Letters">Offer Letters</option>
                  <option value="ID Proofs">ID Proofs & Visas</option>
                  <option value="Certifications">Certifications</option>
                  <option value="Tax Forms">Tax Forms</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Expiration Date (Optional)</label>
                <input
                  type="text"
                  value={expiryDate}
                  onChange={(e) => setExpiryDate(e.target.value)}
                  placeholder="e.g. Dec 2026"
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-800 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-100"
                />
              </div>

              <div className="pt-2 flex space-x-2.5">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="flex-1 border border-slate-200 rounded-lg py-2.5 text-xs font-bold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-350 dark:hover:bg-slate-850"
                >
                  Discard
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 text-white rounded-lg py-2.5 text-xs font-extrabold hover:bg-blue-700 transition"
                >
                  Upload File
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
