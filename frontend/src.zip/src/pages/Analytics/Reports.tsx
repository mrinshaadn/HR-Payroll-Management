import React, { useState } from 'react';
import { useHR } from '../../context/HRContext';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  CartesianGrid, 
  Legend 
} from 'recharts';
import { 
  FileText, 
  Download, 
  Upload, 
  Plus, 
  Users, 
  Briefcase, 
  TrendingUp, 
  Building2, 
  Trash2,
  X,
  FileCheck2,
  ArrowRight
} from 'lucide-react';

const growthQuarterData = [
  { name: 'Q1 2026', Engineering: 35, Marketing: 15, Sales: 22 },
  { name: 'Q2 2026', Engineering: 42, Marketing: 18, Sales: 25 },
  { name: 'Q3 2026', Engineering: 50, Marketing: 24, Sales: 28 },
  { name: 'Q4 2026', Engineering: 62, Marketing: 30, Sales: 34 }
];

const recruitFunnelMap = [
  { stage: 'Applied', count: 180 },
  { stage: 'Screening', count: 120 },
  { stage: 'Interview', count: 75 },
  { stage: 'Offer Stage', count: 32 },
  { stage: 'Hired', count: 18 }
];

export default function Reports() {
  const { 
    documents, 
    addDocument, 
    deleteDocument, 
    addNotification 
  } = useHR();

  const [activeSegment, setActiveSegment] = useState<'growth' | 'vault'>('growth');

  const [growthWidth, setGrowthWidth] = React.useState(0);
  const growthRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    let growthObserver: ResizeObserver | null = null;

    if (growthRef.current) {
      growthObserver = new ResizeObserver((entries) => {
        if (entries[0]) setGrowthWidth(entries[0].contentRect.width);
      });
      growthObserver.observe(growthRef.current);
    }

    return () => {
      if (growthObserver) growthObserver.disconnect();
    };
  }, [activeSegment]);

  // Vault Form fields
  const [showDocModal, setShowDocModal] = useState(false);
  const [docName, setDocName] = useState('');
  const [docType, setDocType] = useState('PDF');

  const handleAddDoc = (e: React.FormEvent) => {
    e.preventDefault();
    if (!docName) {
      addNotification('Please fill Document Name.', 'warning');
      return;
    }
    addDocument({
      name: docName,
      type: docType,
      size: '1.2 MB',
      updatedAt: 'Just Now'
    });
    setDocName('');
    setShowDocModal(false);
  };

  const downloadDocFile = (name: string) => {
    addNotification(`Initiated download file: ${name}`, 'success');
  };

  return (
    <div className="space-y-6">
      
      {/* HEADER ROW */}
      <div className="flex flex-col justify-between space-y-3 sm:flex-row sm:items-center sm:space-y-0">
        <div>
          <h1 className="text-xl font-extrabold tracking-tight text-slate-900 dark:text-white md:text-2xl">Reports &amp; Analytics</h1>
          <p className="text-xs font-semibold text-slate-400 dark:text-slate-500">Corporate intelligence grids, vacancy funnels, and corporate document vaults</p>
        </div>
        
        {/* Navigation Segments Toggle */}
        <div className="flex bg-slate-100 p-1 rounded-lg dark:bg-slate-800">
          <button
            onClick={() => setActiveSegment('growth')}
            className={`px-3 py-1.5 rounded text-xs font-bold transition ${
              activeSegment === 'growth'
                ? 'bg-white shadow text-slate-900 dark:bg-slate-700 dark:text-white'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            Workforce Growth
          </button>
          <button
            onClick={() => setActiveSegment('vault')}
            className={`px-3 py-1.5 rounded text-xs font-bold transition ${
              activeSegment === 'vault'
                ? 'bg-white shadow text-slate-900 dark:bg-slate-700 dark:text-white'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            Doc Vault
          </button>
        </div>
      </div>

      {/* SEGMENT 2: WORKFORCE GROWTH */}
      {activeSegment === 'growth' && (
        <div className="rounded-xl border border-slate-100 bg-white p-5 shadow-sm dark:border-slate-805 dark:bg-slate-850 space-y-4">
          <div>
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-400">Quarterly Department Performance Growth</h3>
            <p className="text-[10px] text-slate-400">Growth trends representing quarterly fulltime headcount additions</p>
          </div>
          
          <div className="h-64 w-full pt-4" ref={growthRef}>
            {growthWidth > 0 && (
              <LineChart width={growthWidth} height={256} data={growthQuarterData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} stroke="#94a3b8" />
                <YAxis tick={{ fontSize: 10 }} stroke="#94a3b8" />
                <Tooltip contentStyle={{ fontSize: '10px' }} />
                <Legend wrapperStyle={{ fontSize: '10px' }} />
                <Line type="monotone" dataKey="Engineering" stroke="#2563eb" strokeWidth={2.5} />
                <Line type="monotone" dataKey="Marketing" stroke="#ec4899" strokeWidth={2.5} />
                <Line type="monotone" dataKey="Sales" stroke="#10b981" strokeWidth={2.5} />
              </LineChart>
            )}
          </div>
        </div>
      )}

      {/* SEGMENT 3: SECURE DOCUMENT VAULT */}
      {activeSegment === 'vault' && (
        <div className="space-y-4">
          
          {/* Vault Top filter */}
          <div className="rounded-xl border border-slate-100 bg-white p-4 shadow-sm dark:border-slate-805 dark:bg-slate-850 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <FileCheck2 className="h-4.5 w-4.5 text-blue-500" />
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-450">Secure Company Vault</h3>
            </div>
            <button
              onClick={() => setShowDocModal(true)}
              className="inline-flex h-8 items-center space-x-1 rounded bg-blue-600 px-3 text-[10px] font-black text-white hover:bg-blue-700 transition"
            >
              <Upload className="h-3.5 w-3.5" />
              <span>Upload Document</span>
            </button>
          </div>

          <div className="overflow-hidden rounded-xl border border-slate-100 bg-white shadow-sm dark:border-slate-805 dark:bg-slate-850">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-100 bg-slate-50/70 text-[10px] font-extrabold uppercase tracking-widest text-slate-400 dark:border-slate-800 dark:bg-slate-800/40">
                    <th className="px-6 py-3.5">Document Title</th>
                    <th className="px-6 py-3.5">File Format</th>
                    <th className="px-6 py-3.5">Size Limit</th>
                    <th className="px-6 py-3.5">Last Synced Date</th>
                    <th className="px-6 py-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs font-bold text-slate-700 dark:divide-slate-800/40 dark:text-slate-350">
                  {documents.map((doc) => (
                    <tr key={doc.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/10">
                      
                      <td className="px-6 py-3.5">
                        <div className="flex items-center space-x-2.5">
                          <FileText className="h-4 w-4 text-blue-500" />
                          <span className="text-slate-900 dark:text-white">{doc.name}</span>
                        </div>
                      </td>

                      <td className="px-6 py-3.5 text-slate-400 font-semibold">{doc.type}</td>
                      <td className="px-6 py-3.5 text-slate-400 font-semibold">{doc.size}</td>
                      <td className="px-6 py-3.5 text-slate-400 font-semibold">{doc.updatedAt}</td>

                      <td className="px-6 py-3.5 text-right space-x-1">
                        <button
                          onClick={() => downloadDocFile(doc.name)}
                          className="p-1.5 rounded hover:bg-blue-50 text-slate-400 hover:text-blue-600"
                          title="Download document PDF"
                        >
                          <Download className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => deleteDocument(doc.id)}
                          className="p-1.5 rounded hover:bg-rose-50 text-slate-400 hover:text-rose-600"
                          title="Remove from vault"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </td>

                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}



      {/* UPLOAD DOC MODAL */}
      {showDocModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-[2px] p-4">
          <div className="w-full max-w-sm rounded-xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-slate-100 uppercase tracking-widest">Upload Company Document</h3>
              <button onClick={() => setShowDocModal(false)} className="rounded p-1 hover:bg-slate-100 dark:hover:bg-slate-800">
                <X className="h-4 w-4 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleAddDoc} className="mt-4 space-y-4">
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">Document Title *</label>
                <input
                  required
                  type="text"
                  value={docName}
                  onChange={(e) => setDocName(e.target.value)}
                  placeholder="e.g. W4 Employee Tax Ledger.pdf"
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-xs text-slate-800 dark:border-slate-800"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">File structure format</label>
                <select
                  value={docType}
                  onChange={(e) => setDocType(e.target.value)}
                  className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-slate-50 px-2 text-xs text-slate-800 dark:border-slate-800"
                >
                  <option value="PDF">PDF Portable Document</option>
                  <option value="DOCX">Microsoft Word</option>
                  <option value="XLSX">Spreadsheet Workbook</option>
                  <option value="ZIP">ZIP Compressed Vault</option>
                </select>
              </div>

              <div className="pt-2 flex space-x-2.5">
                <button
                  type="button"
                  onClick={() => setShowDocModal(false)}
                  className="flex-1 border border-slate-200 rounded-lg py-2.5 text-xs font-bold text-slate-700 hover:bg-slate-50"
                >
                  Discard
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 text-white rounded-lg py-2.5 text-xs font-extrabold hover:bg-blue-700"
                >
                  Upload File
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
