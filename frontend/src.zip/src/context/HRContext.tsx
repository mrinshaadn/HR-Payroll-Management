import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Employee, 
  LeaveRequest, 
  AttendanceRecord, 
  LoanRecord, 
  RecruitmentCandidate, 
  DocumentRecord, 
  GoalRecord, 
  CompanySettings,
  HRState
} from '../types';

interface HRContextProps extends HRState {
  addEmployee: (employee: Omit<Employee, 'id' | 'avatar' | 'metrics' | 'journey'>) => void;
  updateEmployee: (id: string, updated: Partial<Employee>) => void;
  deleteEmployee: (id: string) => void;
  addLeaveRequest: (req: Omit<LeaveRequest, 'id' | 'status'>) => void;
  updateLeaveRequestStatus: (id: string, status: 'APPROVED' | 'REJECTED') => void;
  addLoan: (loan: Omit<LoanRecord, 'id' | 'status' | 'outstandingBalance'> & { totalAmount?: number; remainingAmount?: number; monthsRemaining?: number }) => void;
  updateLoanStatus: (id: string, status: LoanRecord['status']) => void;
  addDocument: (doc: Omit<DocumentRecord, 'id' | 'uploadDate'>) => void;
  deleteDocument: (id: string) => void;
  addCandidate: (candidate: Omit<RecruitmentCandidate, 'id' | 'avatar' | 'tags' | 'experience' | 'score'> & { status?: string; appliedDate?: string }) => void;
  deleteCandidate: (id: string) => void;
  updateCandidateStage: (id: string, stage: RecruitmentCandidate['stage']) => void;
  updateSettings: (settings: Partial<CompanySettings>) => void;
  clockInActive: boolean;
  toggleClockIn: () => void;
  isAuthenticated: boolean;
  user: { name: string; email: string; role: string; avatar: string } | null;
  loginUser: (email: string, pass: string) => boolean;
  logoutUser: () => void;
  addNotification: (message: string, type: 'info' | 'success' | 'warning') => void;
  notifications: Array<{ id: string; text: string; time: string; read: boolean; type: string }>;
  clearNotifications: () => void;
  currentPayCycleProgress: number; // 0-100
  payCycleStep: number; // 1-6
  advancePayCycleStep: () => void;
  resetPayCycle: () => void;
  config: CompanySettings;
}

const HRContext = createContext<HRContextProps | undefined>(undefined);

const initialEmployees: Employee[] = [
  {
    id: 'EMP-8829',
    name: 'Eleanor Vance',
    email: 'eleanormo@gmail.com',
    phone: '(233) 456-7890',
    status: 'ACTIVE',
    department: 'Engineering',
    role: 'Senior Product Designer',
    manager: 'Sarah Jenkins',
    joinDate: 'Oct 11, 2021',
    location: 'New York Office',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
    salary: 135000,
    personalInfo: {
      fullName: 'Eleanor Vance',
      emailAddress: 'eleanormo@gmail.com',
      phoneNumber: '(233) 456-7890',
      statusLabel: 'Active Full-Time',
      emergencyContact: 'John Vance (Husband) - (233) 456-7891',
      healthBenefits: 'Premium Dental & Visual (BCBS)',
      office: 'New York Office (HQ)',
      productStatus: 'Designer Lead Role',
    },
    metrics: {
      attendanceRate: 98.4,
      leaveBalance: 14,
      hireDateTrend: 'Hired 3 Years Ago',
      attendanceTrend: [95, 96, 98, 97, 98, 99, 98, 98.4],
    },
    journey: [
      { id: '1', date: 'Oct 11, 2021', title: 'Hired as Product Designer', description: 'Joined the core technology team in NY HQ Office.', type: 'HIRED' },
      { id: '2', date: 'Mar 20, 2022', title: 'Promoted to Product Designer', description: 'Awarded top quarterly designer award for leadership.', type: 'PROMOTION' },
      { id: '3', date: 'Nov 18, 2023', title: 'Promoted to Sr. Product Designer', description: 'Stepped into leading cross-functional squads.', type: 'PROMOTION' },
      { id: '4', date: 'Dec 14, 2023', title: 'Outstanding Contribution Award', description: 'Received CEO Outstanding Modernity Award.', type: 'AWARD' }
    ]
  },
  {
    id: 'EMP-8422',
    name: 'Sarah Jenkins',
    email: 'sarah.j@enterprise.co',
    phone: '(415) 888-0192',
    status: 'ACTIVE',
    department: 'Engineering',
    role: 'Full Stack Director',
    manager: 'Marcus Sterling',
    joinDate: 'Oct 12, 2021',
    location: 'London, UK',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150',
    salary: 165000,
    personalInfo: {
      fullName: 'Sarah Jenkins',
      emailAddress: 'sarah.j@enterprise.co',
      phoneNumber: '(415) 888-0192',
      statusLabel: 'Active Director',
      emergencyContact: 'Mark Jenkins - (415) 888-0191',
      healthBenefits: 'Enterprise Platinum Direct',
      office: 'London Shard Office',
      productStatus: 'Full Stack Authority',
    },
    metrics: {
      attendanceRate: 99.1,
      leaveBalance: 18,
      hireDateTrend: 'Hired 3 Years Ago',
      attendanceTrend: [98, 99, 99, 99, 100, 99.1],
    },
    journey: [
      { id: 'j1', date: 'Oct 12, 2021', title: 'Director Hired', description: 'Joined to build internal infrastructure.', type: 'HIRED' }
    ]
  },
  {
    id: 'EMP-9012',
    name: 'Michael Chen',
    email: 'm.chen@enterprise.co',
    phone: '(312) 555-0143',
    status: 'ON LEAVE',
    department: 'Marketing',
    role: 'Lead Designer',
    manager: 'Jamo Sonomer',
    joinDate: 'Jan 05, 2019',
    location: 'San Francisco, US',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
    salary: 120000,
    personalInfo: {
      fullName: 'Michael Chen',
      emailAddress: 'm.chen@enterprise.co',
      phoneNumber: '(312) 555-0143',
      statusLabel: 'On Leave (Sabbatical)',
      emergencyContact: 'Lily Chen - (312) 555-0144',
      healthBenefits: 'Standard Dental Care Plus',
      office: 'San Francisco Hub',
      productStatus: 'Lead Creative',
    },
    metrics: {
      attendanceRate: 92.5,
      leaveBalance: 8,
      hireDateTrend: 'Hired 5 Years Ago',
      attendanceTrend: [90, 91, 92, 92.5],
    },
    journey: [
      { id: 'j2', date: 'Jan 05, 2019', title: 'Senior Brand Designer', description: 'Joined the design wing in SF.', type: 'HIRED' }
    ]
  },
  {
    id: 'EMP-3310',
    name: 'Amara Okafor',
    email: 'a.okafor@enterprise.co',
    phone: '(202) 555-0177',
    status: 'REMOTE',
    department: 'HR & Admin',
    role: 'Talent Acquisition Partner',
    manager: 'Amen Sanith',
    joinDate: 'May 22, 2022',
    location: 'Berlin, DE',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    salary: 95000,
    personalInfo: {
      fullName: 'Amara Okafor',
      emailAddress: 'a.okafor@enterprise.co',
      phoneNumber: '(202) 555-0177',
      statusLabel: 'Active Remote',
      emergencyContact: 'Uche Okafor - (202) 555-0178',
      healthBenefits: 'Global Remote Gold Pack',
      office: 'Berlin Remote',
      productStatus: 'Talent Scout Specialist',
    },
    metrics: {
      attendanceRate: 98.7,
      leaveBalance: 12,
      hireDateTrend: 'Hired 2 Years Ago',
      attendanceTrend: [97, 98, 98, 98.7],
    },
    journey: []
  },
  {
    id: 'EMP-2155',
    name: 'David Miller',
    email: 'd.miller@enterprise.co',
    phone: '(617) 555-0311',
    status: 'ACTIVE',
    department: 'Finance',
    role: 'Senior Financial Analyst',
    manager: 'Michael Romer',
    joinDate: 'Aug 15, 2023',
    location: 'Toronto, CA',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
    salary: 110000,
    personalInfo: {
      fullName: 'David Miller',
      emailAddress: 'd.miller@enterprise.co',
      phoneNumber: '(617) 555-0311',
      statusLabel: 'Active Analyst',
      emergencyContact: 'Sarah Miller - (617) 555-0312',
      healthBenefits: 'Canada Standard Care Plus',
      office: 'Toronto Core Site',
      productStatus: 'Budget Compliance Lead',
    },
    metrics: {
      attendanceRate: 97.9,
      leaveBalance: 15,
      hireDateTrend: 'Hired 1 Year Ago',
      attendanceTrend: [96, 97, 97.9],
    },
    journey: []
  }
];

const initialLeaveRequests: LeaveRequest[] = [
  { id: '1', employeeName: 'Marcus Chen', employeeAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150', leaveType: 'Annual Leave', reason: 'Annual Family Vacation', dates: 'Aug 02 - Aug 10, 2023', duration: '7 Days', status: 'APPROVED' },
  { id: '2', employeeName: 'Sarah Miller', employeeAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150', leaveType: 'Annual Leave', reason: 'Receipt attention and moving house', dates: 'Aug 09 - May 10, 2023', duration: '10 Days', status: 'APPROVED' },
  { id: '3', employeeName: 'Robert Fox', employeeAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150', leaveType: 'Sick Leave', reason: 'Peonant enough food poisoning', dates: 'Jun 14 - Apr 15, 2023', duration: '1 Day', status: 'PENDING' },
  { id: '4', employeeName: 'Marcus Chen', employeeAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150', leaveType: 'Annual Leave', reason: 'Advice employees rest', dates: 'Aug 02 - May 10, 2023', duration: '7 Days', status: 'APPROVED' },
  { id: '5', employeeName: 'Jane Cooper', employeeAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', leaveType: 'Annual Leave', reason: 'Sick reason doctor checkup', dates: 'May 10 - May 15, 2023', duration: '5 Days', status: 'REJECTED' },
  { id: '6', employeeName: 'Robert Fox', employeeAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150', leaveType: 'Sick Leave', reason: 'Regular health review', dates: 'Jun 14 - May 15, 2023', duration: '1 Day', status: 'APPROVED' }
];

const initialAttendanceRecords: AttendanceRecord[] = [
  { id: '1', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', name: 'Eleanor Vance', employeeId: 'EMP-8829', shiftType: 'Morning', clockIn: '08:52:15 AM', clockOut: '05:45:00 PM', workHours: '38 hrs', overtime: '2.5 hrs', status: 'Present' },
  { id: '2', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150', name: 'Michael Chen', employeeId: 'EMP-9012', shiftType: 'Evening', clockIn: '08:52:15 AM', clockOut: '08:52:15 AM', workHours: '30 hrs', overtime: '0.00', status: 'Late' },
  { id: '3', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150', name: 'David Miller', employeeId: 'EMP-2155', shiftType: 'Night', clockIn: '08:52:15 AM', clockOut: '08:52:15 AM', workHours: '30 hrs', overtime: '0.00', status: 'WFH' },
  { id: '4', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150', name: 'Sarah Jenkins', employeeId: 'EMP-8422', shiftType: 'Absent', clockIn: '-', clockOut: '-', workHours: '30 hrs', overtime: '-', status: 'Absent' },
  { id: '5', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', name: 'Amara Okafor', employeeId: 'EMP-3310', shiftType: 'Morning', clockIn: '08:52:15 AM', clockOut: '08:52:15 AM', workHours: '30 hrs', overtime: '0.00', status: 'Present' }
];

const initialLoans: LoanRecord[] = [
  { id: 'LOAN-101', employeeId: 'EMP-8829', employeeName: 'Eleanor Vance', employeeAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150', loanType: 'Personal', requestedAmount: 50000, approvedAmount: 50000, emi: 15000, outstandingBalance: 35000, status: 'Approved', totalAmount: 50000, remainingAmount: 35000, monthsRemaining: 3 },
  { id: 'LOAN-102', employeeId: 'EMP-8422', employeeName: 'Sarah Jenkins', employeeAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150', loanType: 'Salary Advance', requestedAmount: 40000, approvedAmount: 40000, emi: 10000, outstandingBalance: 20000, status: 'Pending', totalAmount: 40000, remainingAmount: 20000, monthsRemaining: 2 },
  { id: 'LOAN-103', employeeId: 'EMP-9012', employeeName: 'Michael Chen', employeeAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150', loanType: 'Emergency', requestedAmount: 30000, approvedAmount: 30000, emi: 10000, outstandingBalance: 30050, status: 'Rejected', totalAmount: 30000, remainingAmount: 30050, monthsRemaining: 3 },
  { id: 'LOAN-104', employeeId: 'EMP-2155', employeeName: 'David Miller', employeeAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150', loanType: 'Education', requestedAmount: 100000, approvedAmount: 80000, emi: 40000, outstandingBalance: 80000, status: 'Closed', totalAmount: 80000, remainingAmount: 80000, monthsRemaining: 2 }
];

const initialCandidates: RecruitmentCandidate[] = [
  { id: 'c1', name: 'James Wilson', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150', role: 'Principal UX Lead', tags: ['Design Systems', 'React Native', 'Accessibility'], experience: '12+ Years', score: '92%', stage: 'Applied' },
  { id: 'c2', name: 'Sarah Ellken', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150', role: 'Principal UX Lead', tags: ['Design Systems', 'React Native', 'Accessibility'], experience: '12+ Years', score: '92%', stage: 'Screening' },
  { id: 'c3', name: 'Evin Nuliny', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150', role: 'Principal UX Lead', tags: ['Design Systems', 'React Native', 'Accessibility'], experience: '12+ Years', score: '92%', stage: 'Interviews' },
  { id: 'c4', name: 'Sarah Jenkins', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150', role: 'Principal UX Lead', tags: ['Design Systems', 'React Native', 'Accessibility'], experience: '12+ Years', score: '92%', stage: 'Final Stage' },
  { id: 'c5', name: 'Borial Jihanson', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150', role: 'Principal UX Lead', tags: ['Design Systems', 'React Native'], experience: '12+ Years', score: '97%', stage: 'Applied' },
  { id: 'c6', name: 'Sarah Eliven', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', role: 'Principal UX Lead', tags: ['Design Systems', 'React Native'], experience: '12+ Years', score: '92%', stage: 'Applied' }
];

const initialDocuments: DocumentRecord[] = [
  { id: 'd1', name: 'Compliance Docs', category: 'Contracts', ownerName: 'Alex Rivera', ownerAvatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150', uploadDate: 'Mar 2023', expiryDate: 'May 2023', status: 'Expiring Soon' },
  { id: 'd2', name: 'Safety Cert', category: 'Certifications', ownerName: 'Alex Rivera', ownerAvatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150', uploadDate: 'Dec 2023', expiryDate: 'May 2023', status: 'Expired' },
  { id: 'd3', name: 'ID Proofs', category: 'ID Proofs', ownerName: 'Alex Rivera', ownerAvatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150', uploadDate: 'Dec 2023', expiryDate: 'May 2023', status: 'Missing' },
  { id: 'd4', name: 'Contracts/Opeotant', category: 'Contracts', ownerName: 'Alex Rivera', ownerAvatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150', uploadDate: 'May 2023', expiryDate: 'Dec 2023', status: 'Expired' },
  { id: 'd5', name: 'Visa Docs', category: 'ID Proofs', ownerName: 'Alex Rivera', ownerAvatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150', uploadDate: 'Nov 2023', expiryDate: 'May 2023', status: 'Active' }
];

const initialGoals: GoalRecord[] = [
  { id: 'g1', title: 'Cloud Infrastructure Migration', progress: 65, dueDate: 'Dec 15, 2025', status: 'ON TRACK', manager: 'Marcus Sterling' },
  { id: 'g2', title: 'Q4 Sales Target - EMEA', progress: 32, dueDate: 'Dec 31, 2024', status: 'AT RISK', manager: 'Amy Laurent' },
  { id: 'g3', title: 'Team Leadership Training', progress: 90, dueDate: 'Nov 20, 2024', status: 'ON TRACK', manager: 'Brian Waters' }
];

const defaultSettings: CompanySettings = {
  legalEntityName: 'Global Innovations Tech Group',
  companyDomain: 'global-tech-inc.com',
  primaryIndustry: 'Technology & Software',
  headquartersAddress: '450 Tech Plaza, Floor 12, San Francisco, CA 94105, USA',
  employeeCountRange: '1,001 - 5,000',
  primaryColor: '#004ac6',
  themeMode: 'dark',
  companyName: 'Global Innovations Tech Group',
  adminEmail: 'admin@enterprise.co',
  payCycle: 'Semi-monthly',
  timezone: 'EST - Eastern Standard Time',
  requireTwoFactor: false
};

export const HRProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [employees, setEmployees] = useState<Employee[]>(() => {
    const saved = localStorage.getItem('hr_employees');
    return saved ? JSON.parse(saved) : initialEmployees;
  });

  const [leaveRequests, setLeaveRequests] = useState<LeaveRequest[]>(() => {
    const saved = localStorage.getItem('hr_leave_requests');
    return saved ? JSON.parse(saved) : initialLeaveRequests;
  });

  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>(() => {
    const saved = localStorage.getItem('hr_attendance');
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as AttendanceRecord[];
        const seenIds = new Set<string>();
        return parsed.map((item, idx) => {
          if (!item.id || seenIds.has(item.id) || item.id === 'clock-eleanor') {
            const newId = `clock-${item.employeeId}-${idx}-${Math.random().toString(36).substr(2, 5)}`;
            seenIds.add(newId);
            return { ...item, id: newId };
          }
          seenIds.add(item.id);
          return item;
        });
      } catch (e) {
        return initialAttendanceRecords;
      }
    }
    return initialAttendanceRecords;
  });

  const [loans, setLoans] = useState<LoanRecord[]>(() => {
    const saved = localStorage.getItem('hr_loans');
    return saved ? JSON.parse(saved) : initialLoans;
  });

  const [candidates, setCandidates] = useState<RecruitmentCandidate[]>(() => {
    const saved = localStorage.getItem('hr_candidates');
    return saved ? JSON.parse(saved) : initialCandidates;
  });

  const [documents, setDocuments] = useState<DocumentRecord[]>(() => {
    const saved = localStorage.getItem('hr_documents');
    return saved ? JSON.parse(saved) : initialDocuments;
  });

  const [goals, setGoals] = useState<GoalRecord[]>(() => {
    const saved = localStorage.getItem('hr_goals');
    return saved ? JSON.parse(saved) : initialGoals;
  });

  const [settings, setSettings] = useState<CompanySettings>(() => {
    const saved = localStorage.getItem('hr_settings');
    return saved ? JSON.parse(saved) : defaultSettings;
  });

  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [clockInActive, setClockInActive] = useState(false);

  // Authentication State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    const session = localStorage.getItem('hr_session_auth');
    return session === 'true';
  });

  const [user, setUser] = useState<{ name: string; email: string; role: string; avatar: string } | null>(() => {
    const session = localStorage.getItem('hr_session_user');
    return session ? JSON.parse(session) : {
      name: 'Alex Rivera',
      email: 'alex.rivera@enterprise.co',
      role: 'HR Manager',
      avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150'
    };
  });

  // Payroll Progress Cycle
  const [payCycleStep, setPayCycleStep] = useState<number>(3);
  const [currentPayCycleProgress, setCurrentPayCycleProgress] = useState<number>(75);

  // Notifications State
  const [notifications, setNotifications] = useState<Array<{ id: string; text: string; time: string; read: boolean; type: string }>>([
    { id: 'n1', text: 'Payroll finalized for cycle Nov 1-15', time: '3m ago', read: false, type: 'success' },
    { id: 'n2', text: 'Robert Fox submitted sick leave request', time: '1h ago', read: false, type: 'info' },
    { id: 'n3', text: 'Missing Tax ID for Employee David Lee', time: '2h ago', read: false, type: 'warning' }
  ]);

  useEffect(() => {
    // Always apply dark theme class for consistent enterprise UI theme
    document.documentElement.classList.add('dark');
  }, [settings.themeMode]);

  useEffect(() => {
    localStorage.setItem('hr_employees', JSON.stringify(employees));
  }, [employees]);

  useEffect(() => {
    localStorage.setItem('hr_leave_requests', JSON.stringify(leaveRequests));
  }, [leaveRequests]);

  useEffect(() => {
    localStorage.setItem('hr_attendance', JSON.stringify(attendanceRecords));
  }, [attendanceRecords]);

  useEffect(() => {
    localStorage.setItem('hr_loans', JSON.stringify(loans));
  }, [loans]);

  useEffect(() => {
    localStorage.setItem('hr_candidates', JSON.stringify(candidates));
  }, [candidates]);

  useEffect(() => {
    localStorage.setItem('hr_documents', JSON.stringify(documents));
  }, [documents]);

  useEffect(() => {
    localStorage.setItem('hr_goals', JSON.stringify(goals));
  }, [goals]);

  useEffect(() => {
    localStorage.setItem('hr_settings', JSON.stringify(settings));
  }, [settings]);

  // Actions
  const addNotification = (text: string, type: 'info' | 'success' | 'warning' = 'info') => {
    const newNotif = {
      id: Math.random().toString(36).substr(2, 9),
      text,
      time: 'Just now',
      read: false,
      type
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  const clearNotifications = () => {
    setNotifications([]);
  };

  const addEmployee = (newEmp: Omit<Employee, 'id' | 'avatar' | 'metrics' | 'journey'>) => {
    const idNum = Math.floor(1000 + Math.random() * 9000);
    const id = `EMP-${idNum}`;
    const employeeWithId: Employee = {
      ...newEmp,
      id,
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150', // placeholder
      personalInfo: {
        fullName: newEmp.name,
        emailAddress: newEmp.email,
        phoneNumber: newEmp.phone,
        statusLabel: 'Active ' + newEmp.status,
        emergencyContact: 'Emergency Ref - 555-0100',
        healthBenefits: 'Dental, Physical & Eye Plus',
        office: newEmp.location,
        productStatus: newEmp.role + ' Position'
      },
      metrics: {
        attendanceRate: 98.0,
        leaveBalance: 15,
        hireDateTrend: 'Just Hired',
        attendanceTrend: [98, 98, 98]
      },
      journey: [
        { id: '1', date: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }), title: 'Joined Company', description: `Started as ${newEmp.role} in ${newEmp.location}`, type: 'HIRED' }
      ]
    };
    setEmployees(prev => [employeeWithId, ...prev]);
    addNotification(`Added new employee: ${newEmp.name}`, 'success');

    // Create a matching morning attendance record for active employees automatically
    if (newEmp.status === 'ACTIVE') {
      const newAtt: AttendanceRecord = {
        id: Math.random().toString(36).substr(2, 9),
        avatar: employeeWithId.avatar,
        name: employeeWithId.name,
        employeeId: employeeWithId.id,
        shiftType: 'Morning',
        clockIn: '08:52:15 AM',
        clockOut: '-',
        workHours: '30 hrs',
        overtime: '0.00',
        status: 'Present'
      };
      setAttendanceRecords(prev => [newAtt, ...prev]);
    }
  };

  const updateEmployee = (id: string, updated: Partial<Employee>) => {
    setEmployees(prev => prev.map(emp => {
      if (emp.id === id) {
        const merged = { ...emp, ...updated };
        // Sync personalInfo if name/email/phone/role/location changed
        merged.personalInfo = {
          ...emp.personalInfo,
          fullName: merged.name,
          emailAddress: merged.email,
          phoneNumber: merged.phone,
          statusLabel: 'Active ' + merged.status,
          office: merged.location,
        };
        return merged;
      }
      return emp;
    }));
    addNotification(`Updated profile for employee: ID ${id}`, 'info');
  };

  const deleteEmployee = (id: string) => {
    setEmployees(prev => prev.filter(emp => emp.id !== id));
    addNotification(`Terminated/Removed employee record for ID ${id}`, 'warning');
  };

  const addLeaveRequest = (req: Omit<LeaveRequest, 'id' | 'status'>) => {
    const newReq: LeaveRequest = {
      ...req,
      id: Math.random().toString(36).substr(2, 9),
      status: 'PENDING'
    };
    setLeaveRequests(prev => [newReq, ...prev]);
    addNotification(`New leave request from ${req.employeeName} (${req.leaveType})`, 'info');
  };

  const updateLeaveRequestStatus = (id: string, status: 'APPROVED' | 'REJECTED') => {
    setLeaveRequests(prev => prev.map(req => {
      if (req.id === id) {
        // deduct leave balances on approval
        if (status === 'APPROVED') {
          setEmployees(prevEmp => prevEmp.map(emp => {
            if (emp.name === req.employeeName) {
              return {
                ...emp,
                metrics: {
                  ...emp.metrics,
                  leaveBalance: Math.max(0, emp.metrics.leaveBalance - parseInt(req.duration) || 1)
                }
              };
            }
            return emp;
          }));
        }
        return { ...req, status };
      }
      return req;
    }));
    addNotification(`Leave request ${status.toLowerCase()} for ${leaveRequests.find(r => r.id === id)?.employeeName}`, status === 'APPROVED' ? 'success' : 'warning');
  };

  const addLoan = (loan: Omit<LoanRecord, 'id' | 'status' | 'outstandingBalance'> & { totalAmount?: number; remainingAmount?: number; monthsRemaining?: number }) => {
    const totalAmount = loan.totalAmount ?? loan.approvedAmount ?? 0;
    const remainingAmount = loan.remainingAmount ?? totalAmount;
    const monthsRemaining = loan.monthsRemaining ?? 12;
    const newLoan: LoanRecord = {
      ...loan,
      employeeId: employees.find(emp => emp.name === loan.employeeName)?.id || 'EMP-TEMP',
      loanType: 'Personal',
      requestedAmount: totalAmount,
      approvedAmount: totalAmount,
      emi: Math.ceil(totalAmount / monthsRemaining),
      outstandingBalance: remainingAmount,
      totalAmount,
      remainingAmount,
      monthsRemaining,
      id: `LOAN-${Math.floor(100 + Math.random() * 900)}`,
      status: 'Pending'
    };
    setLoans(prev => [newLoan, ...prev]);
    addNotification(`Loan request registered for ${loan.employeeName}`, 'info');
  };

  const updateLoanStatus = (id: string, status: LoanRecord['status']) => {
    setLoans(prev => prev.map(l => l.id === id ? { ...l, status } : l));
    addNotification(`Loan ${id} marked as ${status}`, 'info');
  };

  const addDocument = (doc: Omit<DocumentRecord, 'id' | 'uploadDate'>) => {
    const newDoc: DocumentRecord = {
      ...doc,
      id: `d-${Math.random().toString(36).substr(2, 9)}`,
      uploadDate: new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' })
    };
    setDocuments(prev => [newDoc, ...prev]);
    addNotification(`Uploaded document: ${doc.name}`, 'success');
  };

  const deleteDocument = (id: string) => {
    setDocuments(prev => prev.filter(doc => doc.id !== id));
    addNotification(`Deleted document package`, 'warning');
  };

  const addCandidate = (cand: Omit<RecruitmentCandidate, 'id' | 'avatar' | 'tags' | 'experience' | 'score'> & { status?: string; appliedDate?: string }) => {
    const newCand: RecruitmentCandidate = {
      id: `c-${Math.random().toString(36).substr(2, 9)}`,
      name: cand.name,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      role: cand.role,
      tags: ['Design Systems', 'React'],
      experience: '5+ Years',
      score: '90%',
      stage: (cand.status as any) || 'Applied',
      status: cand.status || 'APPLIED',
      appliedDate: cand.appliedDate || 'Just Now'
    };
    setCandidates(prev => [newCand, ...prev]);
    addNotification(`Registered candidate: ${cand.name}`, 'success');
  };

  const deleteCandidate = (id: string) => {
    setCandidates(prev => prev.filter(c => c.id !== id));
    addNotification(`Rejected/Removed candidate profile`, 'warning');
  };

  const updateCandidateStage = (id: string, stage: RecruitmentCandidate['stage']) => {
    setCandidates(prev => prev.map(cand => cand.id === id ? { ...cand, stage, status: stage.toUpperCase() } : cand));
    addNotification(`Candidate moved to ${stage} stage`, 'info');
  };

  const updateSettings = (updated: Partial<CompanySettings>) => {
    setSettings(prev => ({ ...prev, ...updated }));
    addNotification('Company administration settings saved', 'success');
  };

  const toggleClockIn = () => {
    setClockInActive(prev => {
      const state = !prev;
      if (state) {
        addNotification('Clocked in successfully. Session started.', 'success');
        // Add a mock attendance record for Eleanor Vance as Present
        const attendanceExists = attendanceRecords.some(r => r.employeeId === 'EMP-8829' && r.clockOut === '-');
        if (!attendanceExists) {
          const freshRecord: AttendanceRecord = {
            id: `clock-eleanor-${Math.random().toString(36).substr(2, 9)}`,
            avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
            name: 'Eleanor Vance',
            employeeId: 'EMP-8829',
            shiftType: 'Morning',
            clockIn: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
            clockOut: '-',
            workHours: 'Calculating',
            overtime: '0.00',
            status: 'Present'
          };
          setAttendanceRecords(prevAtt => [freshRecord, ...prevAtt]);
        }
      } else {
        addNotification('Clocked out successfully. Session closed.', 'info');
        setAttendanceRecords(prevAtt => prevAtt.map(r => {
          if (r.employeeId === 'EMP-8829' && r.clockOut === '-') {
            return {
              ...r,
              clockOut: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
              workHours: '8.5 hrs',
              overtime: '0.5 hrs'
            };
          }
          return r;
        }));
      }
      return state;
    });
  };

  const loginUser = (email: string, pass: string): boolean => {
    // Allow any non-empty password for easy navigation as requested by simple UX, or match standard admin
    if (email && email.includes('@')) {
      const formattedUser = {
        name: email.split('@')[0].split('.').map(s => s.charAt(0).toUpperCase() + s.slice(1)).join(' '),
        email,
        role: email.startsWith('admin') ? 'HR Director' : 'HR Manager',
        avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150'
      };
      setIsAuthenticated(true);
      setUser(formattedUser);
      localStorage.setItem('hr_session_auth', 'true');
      localStorage.setItem('hr_session_user', JSON.stringify(formattedUser));
      addNotification(`Welcome back, ${formattedUser.name}!`, 'success');
      return true;
    }
    return false;
  };

  const logoutUser = () => {
    setIsAuthenticated(false);
    setUser(null);
    localStorage.removeItem('hr_session_auth');
    localStorage.removeItem('hr_session_user');
  };

  const advancePayCycleStep = () => {
    setPayCycleStep(prev => {
      const next = prev < 6 ? prev + 1 : 1;
      const progressMap = [15, 30, 50, 75, 90, 100];
      setCurrentPayCycleProgress(progressMap[next - 1]);
      
      const stepNames = [
        'Attendance Locked',
        'Deductions Verified',
        'Tax Calculation Completed',
        'Final Review Complete',
        'Bank Transfer Completed',
        'Payslips Generated'
      ];
      addNotification(`Payroll step advanced: ${stepNames[next - 1]}`, 'success');
      return next;
    });
  };

  const resetPayCycle = () => {
    setPayCycleStep(1);
    setCurrentPayCycleProgress(15);
    addNotification('Payroll cycle restarted', 'info');
  };

  return (
    <HRContext.Provider value={{
      employees,
      leaveRequests,
      attendanceRecords,
      loans,
      candidates,
      documents,
      goals,
      settings,
      config: settings,
      sidebarCollapsed,
      addEmployee,
      updateEmployee,
      deleteEmployee,
      addLeaveRequest,
      updateLeaveRequestStatus,
      addLoan,
      updateLoanStatus,
      addDocument,
      deleteDocument,
      addCandidate,
      deleteCandidate,
      updateCandidateStage,
      updateSettings,
      clockInActive,
      toggleClockIn,
      isAuthenticated,
      user,
      loginUser,
      logoutUser,
      notifications,
      addNotification,
      clearNotifications,
      currentPayCycleProgress,
      payCycleStep,
      advancePayCycleStep,
      resetPayCycle
    }}>
      {children}
    </HRContext.Provider>
  );
};

export const useHR = () => {
  const context = useContext(HRContext);
  if (context === undefined) {
    throw new Error('useHR must be used within an HRProvider');
  }
  return context;
};
