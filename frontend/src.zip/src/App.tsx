import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { HRProvider } from './context/HRContext';
import Layout from './components/layout/Layout';
import {
  Auth,
  Dashboard,
  Employees,
  Profile,
  Attendance,
  Leave,
  Payroll,
  Reports,
  Settings,
  Documents,
  Recruitment
} from './pages';


export default function App() {
  return (
    <HRProvider>
      <HashRouter>
        <Routes>
          {/* Public Auth routes */}
          <Route path="/login" element={<Auth />} />

          {/* Secure application shell */}
          <Route path="/" element={<Layout />}>
            <Route index element={<Navigate to="/dashboard" replace />} />
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="employees" element={<Employees />} />
            <Route path="employees/:id" element={<Profile />} />
            <Route path="attendance" element={<Attendance />} />
            <Route path="leave" element={<Leave />} />
            <Route path="payroll" element={<Payroll />} />
            <Route path="recruitment" element={<Recruitment />} />
            <Route path="analytics" element={<Reports />} />
            <Route path="documents" element={<Documents />} />
            <Route path="settings" element={<Settings />} />
          </Route>

          {/* Core redirects */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </HashRouter>
    </HRProvider>
  );
}
