import { mockApi } from './api';
import { RecruitmentCandidate } from '../types';

const STORAGE_KEY = 'hr_candidates';

export const recruitmentService = {
  getCandidates: async (defaultCandidates: RecruitmentCandidate[]): Promise<RecruitmentCandidate[]> => {
    return mockApi.get<RecruitmentCandidate[]>(STORAGE_KEY, defaultCandidates);
  },

  addCandidate: async (candidate: RecruitmentCandidate, currentCandidates: RecruitmentCandidate[]): Promise<RecruitmentCandidate[]> => {
    return mockApi.post<RecruitmentCandidate>(STORAGE_KEY, candidate, currentCandidates);
  },

  deleteCandidate: async (id: string, currentCandidates: RecruitmentCandidate[]): Promise<RecruitmentCandidate[]> => {
    return mockApi.delete<RecruitmentCandidate>(STORAGE_KEY, id, currentCandidates);
  },

  updateCandidateStage: async (id: string, stage: RecruitmentCandidate['stage'], currentCandidates: RecruitmentCandidate[]): Promise<RecruitmentCandidate[]> => {
    return mockApi.put<RecruitmentCandidate>(STORAGE_KEY, id, { stage, status: stage.toUpperCase() }, currentCandidates);
  }
};
