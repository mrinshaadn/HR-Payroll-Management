// Simple mock API helper for simulating network requests
export const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const mockApi = {
  get: async <T>(key: string, defaultData: T): Promise<T> => {
    await delay(300);
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : defaultData;
  },

  post: async <T>(key: string, item: T, list: T[] = []): Promise<T[]> => {
    await delay(300);
    const updated = [item, ...list];
    localStorage.setItem(key, JSON.stringify(updated));
    return updated;
  },

  put: async <T extends { id: string }>(key: string, id: string, updatedItem: Partial<T>, list: T[]): Promise<T[]> => {
    await delay(300);
    const updated = list.map(item => item.id === id ? { ...item, ...updatedItem } : item);
    localStorage.setItem(key, JSON.stringify(updated));
    return updated;
  },

  delete: async <T extends { id: string }>(key: string, id: string, list: T[]): Promise<T[]> => {
    await delay(300);
    const updated = list.filter(item => item.id !== id);
    localStorage.setItem(key, JSON.stringify(updated));
    return updated;
  }
};
