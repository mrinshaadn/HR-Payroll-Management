import { mockApi } from './api';
import { LoanRecord } from '../types';

const LOANS_STORAGE_KEY = 'hr_loans';

export const payrollService = {
  getLoans: async (defaultLoans: LoanRecord[]): Promise<LoanRecord[]> => {
    return mockApi.get<LoanRecord[]>(LOANS_STORAGE_KEY, defaultLoans);
  },

  addLoan: async (loan: LoanRecord, currentLoans: LoanRecord[]): Promise<LoanRecord[]> => {
    return mockApi.post<LoanRecord>(LOANS_STORAGE_KEY, loan, currentLoans);
  },

  updateLoanStatus: async (id: string, status: LoanRecord['status'], currentLoans: LoanRecord[]): Promise<LoanRecord[]> => {
    return mockApi.put<LoanRecord>(LOANS_STORAGE_KEY, id, { status }, currentLoans);
  }
};
