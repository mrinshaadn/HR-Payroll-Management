import { mockApi } from './api';
import { AttendanceRecord } from '../types';

const STORAGE_KEY = 'hr_attendance';

export const attendanceService = {
  getAttendance: async (defaultRecords: AttendanceRecord[]): Promise<AttendanceRecord[]> => {
    return mockApi.get<AttendanceRecord[]>(STORAGE_KEY, defaultRecords);
  },

  saveAttendance: async (records: AttendanceRecord[]): Promise<void> => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
  }
};
