import { delay } from './api';

export interface UserSession {
  name: string;
  email: string;
  role: string;
  avatar: string;
}

export const authService = {
  login: async (email: string, pass: string): Promise<UserSession | null> => {
    await delay(400);
    if (email && email.includes('@')) {
      const user: UserSession = {
        name: email.split('@')[0].split('.').map(s => s.charAt(0).toUpperCase() + s.slice(1)).join(' '),
        email,
        role: email.startsWith('admin') ? 'HR Director' : 'HR Manager',
        avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150'
      };
      localStorage.setItem('hr_session_auth', 'true');
      localStorage.setItem('hr_session_user', JSON.stringify(user));
      return user;
    }
    return null;
  },

  logout: async (): Promise<void> => {
    await delay(200);
    localStorage.removeItem('hr_session_auth');
    localStorage.removeItem('hr_session_user');
  },

  getCurrentUser: (): UserSession | null => {
    const user = localStorage.getItem('hr_session_user');
    return user ? JSON.parse(user) : null;
  },

  isAuthenticated: (): boolean => {
    return localStorage.getItem('hr_session_auth') === 'true';
  }
};
