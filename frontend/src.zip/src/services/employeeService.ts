import { mockApi } from './api';
import { Employee } from '../types';

const STORAGE_KEY = 'hr_employees';

export const employeeService = {
  getEmployees: async (defaultEmployees: Employee[]): Promise<Employee[]> => {
    return mockApi.get<Employee[]>(STORAGE_KEY, defaultEmployees);
  },

  addEmployee: async (employee: Employee, currentList: Employee[]): Promise<Employee[]> => {
    return mockApi.post<Employee>(STORAGE_KEY, employee, currentList);
  },

  updateEmployee: async (id: string, updatedFields: Partial<Employee>, currentList: Employee[]): Promise<Employee[]> => {
    return mockApi.put<Employee>(STORAGE_KEY, id, updatedFields, currentList);
  },

  deleteEmployee: async (id: string, currentList: Employee[]): Promise<Employee[]> => {
    return mockApi.delete<Employee>(STORAGE_KEY, id, currentList);
  }
};
